<?php

define('CODE_SUCCESS', 0);
define('CODE_ERROR', 1);
define('CODE_QUERY', 2);
define('MESSAGE_SUCCESS', 'success');
define('MESSAGE_ERROR', 'error');
define('LOGIN', 'Login');
define('LOGOUT', 'Logout');
define('ADD', 'Add');
define('UPDATE', 'Update');
define('DELETE', 'Delete');
const LATE_OR_SON = 1;

const BASE_API = 'http://10.30.154.66:8080/';

define('VOICE_POLITICS', 'Chính trị');
define('VOICE_EROTIC', 'Nội dung nhạy cảm');
define('VOICE_LICENSE', 'Bản quyền');
define('IMAGE_POLITICS', 'Hình ảnh chính trị');
define('IMAGE_EROTIC', 'Hình ảnh nhạy cảm');
define('IMAGE_LICENSE', 'Hình ảnh bản quyền');

define('MAX_EXECUTION_TIME', 'max_execution_time');
define('PROCESSING_TXT', 'Đang xử lý');
define('PROCESSING_ERROR_TXT', 'Lỗi');
