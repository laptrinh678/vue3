<?php

namespace App\Exports\Concerns;

interface WithCustomProperties
{
    public function title(): string;
}
