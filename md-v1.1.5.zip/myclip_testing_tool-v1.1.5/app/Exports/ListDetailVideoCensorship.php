<?php

namespace App\Exports;

use App\Repositories\Common\PlaylistRepository;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromView;

class ListDetailVideoCensorship implements  FromView
{
    protected $request;
    protected $isDev;
    use Exportable;

    function __construct(Request $request, $isDev)
    {
        $this->request = $request;
        $this->isDev = $isDev;
    }

    public function view(): view
    {
        $datePicked = $this->request->get('datePicked');

        $time = trans('fields.time_rp', [
            'day1' => date("d-m-Y", strtotime($datePicked[0])),
            'day2' => date("d-m-Y", strtotime($datePicked[1]))
        ]);

        $playlistRepo = new PlaylistRepository;

        $params = [
            'datePicked' => $datePicked,
            'keyword' => $this->request->get('keyword'),
            'ground_truth_id' => $this->request->ground_truth_id,
            'valueFilter' => $this->request->valueFilter
        ];

        $total = $playlistRepo->getListCensorshipDetail(
            $params,
            true
        );

        $data = $playlistRepo->getListCensorshipDetail(
            $params,
            false,
            $total,
            0,
            $this->isDev
        );

        if ($this->isDev) {
            return view('excel.ListDetailVideoCensorshipDev', [
                'data' => $data,
                'time' => $time,
            ]);
        }

        return view('excel.ListDetailVideoCensorship', [
            'data' => $data,
            'time' => $time,
        ]);
    }
}
