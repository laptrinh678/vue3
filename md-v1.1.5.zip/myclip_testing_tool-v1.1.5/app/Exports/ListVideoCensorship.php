<?php

namespace App\Exports;

use App\Repositories\Common\PlaylistRepository;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromView;

class ListVideoCensorship implements  FromView
{
    protected $request;
    protected $params;
    use Exportable;

    function __construct(Request $request)
    {
        $this->request = $request;
    }

    public function view(): view
    {
        $datePicked = $this->request->get('datePicked');

        $time = trans('fields.time_rp', [
            'day1'=>date("d-m-Y", strtotime($datePicked[0])),
            'day2'=>date("d-m-Y", strtotime($datePicked[1]))
        ]);

        $playlistRepo = new PlaylistRepository;

        $data = $playlistRepo->getListCensorship(
            $this->request->get('keyword'),
            10,
            0,
            null,
            null,
            $this->request->get('ground_truth_id'),
            $datePicked
        );

        return view('excel.ListVideoCensorship', [
            'data' => $data['data'],
            'time' => $time,
        ]);
    }
}
