<?php

if (!function_exists('includeRouteFiles')) {

    /**
     * Loops through a folder and requires all PHP files
     * Searches sub-directories as well.
     *
     * @param $folder
     */
    function includeRouteFiles($folder)
    {
        try {
            $rdi = new recursiveDirectoryIterator($folder);
            $it = new recursiveIteratorIterator($rdi);

            while ($it->valid()) {
                if (!$it->isDot() && $it->isFile() && $it->isReadable() && $it->current()->getExtension() === 'php') {
                    require $it->key();
                }

                $it->next();
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}

/**
 * get base dataTable request params
 * @param $request
 * @return array
 */
function getDataTableRequestParams($request)
{
    $start = $request->input('start');
    $length = $request->input('length');
    $draw = $request->input('draw');

    $order = $request->input('order');
    $columns = $request->input('columns');
    $search = $request->input('search');
    $keyword = $search['value'];

    $orderBy = null;
    $orderType = null;

    if ($order) {
        $num = $order[0]['column'];
        $orderBy = $columns[$num]['data'];
        $orderType = $order[0]['dir'];
    }

    return [
        'start' => $start,
        'length' => $length,
        'draw' => $draw,
        'orderBy' => $orderBy,
        'orderType' => $orderType,
        'keyword' => $keyword
    ];
}

/**
 * @param $result
 * @param null $data
 * @param null $code
 * @param null $message
 * @return \Illuminate\Http\JsonResponse
 */
function processCommonResponse($result, $data = null, $code = null, $message = null)
{
    $codeError = $result ? CODE_SUCCESS : CODE_ERROR;
    $messageError = $result ? MESSAGE_SUCCESS : MESSAGE_ERROR;

    return response()->json(array(
        'code' => $code ? $code : $codeError,
        'message' => $message ? $message : $messageError,
        'data' => $data
    ));
}

function commonResponse($draw, $data, $total)
{
    return response()->json([
        'draw' => $draw,
        'data' => $data,
        'recordsTotal' => $total,
        'recordsFiltered' => $total
    ]);
}

function formatDatetimeToNormalDate($datetime)
{
    if (!$datetime) {
        return '';
    }

    return \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $datetime)->format('d/m/Y');
}

function formatMnpToText($mnp)
{
    if ($mnp == 1) {
        return 'Có';
    }
    return 'Không';
}

function getFileUpload($file)
{
    $files = json_decode($file);

    if (!empty($files)) {
        return $files[0];
    }

    return null;
}
function getConfig($key='start_time')
{
    return \App\Models\TimeFrame::where('key',$key)->first()['value'];
}

function getProductGroupName($arr)
{
    if ($arr != null) {
        $productGroupName = null;
        for ($i = 0; $i < count($arr); $i++) {
            if ($i == 0) {
                $productGroupName = $arr[$i]->name;
            } else {
                $productGroupName = $productGroupName . ', ' . $arr[$i]->name;
            }
        }
        return $productGroupName;
    }

    return null;
}

function sendRequestWithProxy(){

}
function sendRequest($url, $params = array(), $proxy_link='', $proxy_port='', $header_key='', $method = 'POST', $isJSON = true, $isAuthen = false, $timeOut = 60)
{
    $request = \Ixudra\Curl\Facades\Curl::to($url)
        ->withOption('TIMEOUT', $timeOut)
        ->withOption('CONNECTTIMEOUT', 0)
        ->withOption('SSL_VERIFYPEER', 0)
        ->withContentType('application/json')
        ->withOption('FOLLOWLOCATION', true)
        ->returnResponseObject();
    if($proxy_link !=''){
        $request->withProxy($proxy_link,$proxy_port);
    }
    if($header_key !=''){
        $request->withHeaders(['token'=>'1SYq1CAEG7CAedgBg-2C8N2qsUSF6j3f4-lCqWfrDEFH342cDn6Hps5x40F8WO2k']);
    }
    if ($isJSON) {
        if(count($params)){
            $request->withData(json_encode($params));
        }
    } else {
        $request->withData($params);
    }

    if ($isAuthen) {
        $request->withOption('USERPWD', 'admin:weppoHER4352GGErfg');
    }

    $response = '';
    switch ($method) {
        case 'GET':
            $response = $request->get();
            break;
        case 'POST':
            $response = $request->post();
            break;
        case 'PUT':
            $response = $request->put();
            break;
        case 'PATCH':
            $response = $request->patch();
            break;
        case 'DELETE':
            $response = $request->delete();
            break;
        default:
            break;
    }
    return $response->content;
}

function str_starts_with($str, $substr) {
    return substr($str, 0, strlen($substr)) == $substr;

}

function formatDateTimeUTCCarbon($dateTime, $type = 'Y-m-d H-i-s')
{
    $date = date($type, strtotime($dateTime));
    return Carbon\Carbon::createFromFormat($type, $date, 'UTC');
}