<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Admin\User\ChangePasswordRequest;
use App\Http\Requests\Admin\User\UpdateProfileRequest;
use App\Repositories\Admin\UserRepository;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * @var UserRepository
     */
    protected $userRepository;

    function __construct(UserRepository $userRepository)
    {
        $this->middleware('auth');

        $this->userRepository = $userRepository;
    }

    public function updateProfile(UpdateProfileRequest $request)
    {
        $result = $this->userRepository->updateProfile($request->only('email', 'username'));
        return processCommonResponse($result);
    }

    public function ChangePassword(ChangePasswordRequest $request)
    {
        $result = $this->userRepository->changePassword($request->only('new_password'));
        return processCommonResponse($result);
    }
}
