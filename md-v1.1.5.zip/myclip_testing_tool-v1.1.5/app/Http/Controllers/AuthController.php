<?php

namespace App\Http\Controllers;

use App\Models\Department;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login']]);
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login()
    {
        $credentials = $this->typeLogin();
        if (array_key_exists('name', $credentials)) {
            $credentials['username'] = $credentials['name'];
            unset($credentials['name']);
        }

        if (!$token = auth()->attempt($credentials)) {
            return response()->json([
                'code' => CODE_ERROR,
                'message' => 'Unauthorized'
            ], 401);
        }
        return $this->respondWithToken($token);
    }
    public function typeLogin(){
        $request = request(['name', 'password']);

        if(is_numeric($request['name'])){
            return ['phone'=>$request['name'],'password'=>$request['password']];
        }
        elseif (filter_var($request['name'], FILTER_VALIDATE_EMAIL)) {
            return ['email'=>$request['name'],'password'=>$request['password']];
        }
        return $request;
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        $user = auth()->user();
        return response()->json([
            'user' => $user
        ]);
    }
    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {

        return response()->json([
            'code' => CODE_SUCCESS,
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }
}
