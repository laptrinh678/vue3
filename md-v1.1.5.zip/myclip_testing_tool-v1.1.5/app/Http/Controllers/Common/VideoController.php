<?php

namespace App\Http\Controllers\Common;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use App\Repositories\Common\PlaylistRepository;
use App\Repositories\Common\GroundTruthRepository;
use App\Exports\ListVideoCensorship;
use App\Exports\ListDetailVideoCensorship;
use Maatwebsite\Excel\Excel;
use Maatwebsite\Excel\Concerns\Exportable;

class VideoController extends Controller
{
    use Exportable;

    protected $playlistRepo;
    protected $groundTruthtRepo;
    private $_excel;

    function __construct(
        PlaylistRepository $playlistRepo,
        GroundTruthRepository $groundTruthtRepo,
        Excel $excel
    ) {
        $this->middleware('auth');
        $this->playlistRepo = $playlistRepo;
        $this->groundTruthtRepo = $groundTruthtRepo;
        $this->_excel = $excel;
    }

    public function index(Request $request)
    {
        $tableParams = getDataTableRequestParams($request);

        $data = $this->playlistRepo->getListCensorship(
            $request->get('keyword'),
            $tableParams['length'],
            $tableParams['start'],
            $tableParams['orderBy'],
            $tableParams['orderType'],
            $request->ground_truth_id,
            $request->get('datePicked')
        );

        return commonResponse($tableParams['draw'], $data['data'], $data['count']);
    }

    public function getRequestParams(Request $request)
    {
        return $request->only([
            'datePicked',
            'keyword',
            'valueFilter',
            'ground_truth_id'
        ]);
    }

    public function detail(Request $request)
    {
        $tableParams = getDataTableRequestParams($request);
        $params = $this->getRequestParams($request);

        $total = $this->playlistRepo->getListCensorshipDetail(
            $params,
            true
        );

        $data = $this->playlistRepo->getListCensorshipDetail(
            $params,
            false,
            $tableParams['length'],
            $tableParams['start']
        );

        return commonResponse($tableParams['draw'], $data, $total);
    }

    // Danh sách video đc upload từ API ngoài
    public function detailApi(Request $request)
    {
        $tableParams = getDataTableRequestParams($request);
        $params = $this->getRequestParams($request);

        $total = $this->playlistRepo->getListCensorshipDetailApi(
            $params,
            true
        );

        $data = $this->playlistRepo->getListCensorshipDetailApi(
            $params,
            false,
            $tableParams['length'],
            $tableParams['start'],
            true
        );

        return commonResponse($tableParams['draw'], $data, $total);
    }

    public function detailDev(Request $request)
    {
        $tableParams = getDataTableRequestParams($request);

        $params = $this->getRequestParams($request);

        $total = $this->playlistRepo->getListCensorshipDetail(
            $params,
            true
        );

        $data = $this->playlistRepo->getListCensorshipDetail(
            $params,
            false,
            $tableParams['length'],
            $tableParams['start'],
            true
        );

        return commonResponse($tableParams['draw'], $data, $total);
    }

    public function getPlaylists()
    {
        return $this->playlistRepo->getList();
    }

    public function store(Request $request)
    {
        \DB::beginTransaction();

        try {
            if ($request->file('file')) {
                $playlistId = $this->playlistRepo->store($request->video_playlist_id);

                $videoIds = explode(",", $request->video_ids);

                foreach ($request->file('file') as $key => $file) {
                    $timeStamp = Carbon::now()->timestamp + $key;

                    if (count($videoIds) == 1) {
                        $videoId = $videoIds[0] != "" ? $videoIds[0] : $timeStamp;
                    } else {
                        $videoId = isset($videoIds[$key]) ? $videoIds[$key] : $timeStamp;
                    }

                    $fileMime = explode('/', $file->getClientMimeType())[1];
                    $directory = 'VIDEO/' . date("Y") . '/' . date("m") . '/' . date("d") . '/';
                    $path = $directory . $timeStamp . '.' . $fileMime;

                    if (!Storage::disk('ftp')->exists($directory)) {
                        Storage::disk('ftp')->makeDirectory($directory);
                    }

                    Storage::disk('ftp')->putFileAs(
                        $directory,
                        $file,
                        $timeStamp . '.' . $fileMime
                    );

                    $responses = sendRequest(BASE_API . 'censorship/upload-video', [
                        'video_id' => $videoId,
                        'user_id' => auth()->user()->id,
                        'category_ids' => [$playlistId],
                        'path' => $path,
                        'is_testing' => true
                    ]);

                    $responses = json_decode($responses);

                    if ($responses->code == 200) {
                        $params = [
                            'video_id' => $videoId,
                            'video_playlist_id' => $playlistId,
                            'name' => $file->getClientOriginalName(),
                            'path' => $path,
                            'created_by' => auth()->user()->id,
                            'ground_truth_id' => [$request->ground_truth_id]
                        ];

                        $this->groundTruthtRepo->store($params);
                    } else {
                        return response()->json([
                            'code' => $responses->code,
                            'message' => $responses->message
                        ]);
                    }
                }
            }

            \DB::commit();

            return response()->json([
                'code' => 201
            ]);
        } catch (\Exception $e) {
            \DB::rollback();

            return response()->json([
                'code' => 500
            ]);
        }
    }

    public function export(Request $request)
    {
        ini_set(MAX_EXECUTION_TIME, 60);

        return $this->_excel->download(new ListVideoCensorship($request), 'Thong_ke_ket_qua_kiem_duyet_video.xlsx');
    }

    public function exportDetail(Request $request)
    {
        ini_set(MAX_EXECUTION_TIME, 60);

        return $this->_excel->download(new ListDetailVideoCensorship($request, false), 'Thong_ke_ket_qua_kiem_duyet_video.xlsx');
    }

    public function exportDetailDev(Request $request)
    {
        ini_set(MAX_EXECUTION_TIME, 60);

        return $this->_excel->download(new ListDetailVideoCensorship($request, true), 'Thong_ke_ket_qua_kiem_duyet_video_dev.xlsx');
    }
}
