<?php
/**
 * Created by PhpStorm.
 * User: hungnm
 * Date: 4/2/2019
 * Time: 11:07 AM
 */

namespace App\Http\Requests\Common\Files;

use Illuminate\Foundation\Http\FormRequest;

class DeleteFilesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'required',
        ];
    }
}