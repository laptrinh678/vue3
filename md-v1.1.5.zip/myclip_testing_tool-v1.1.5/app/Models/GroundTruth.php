<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GroundTruth extends Model
{
    const STATUS_PROCESS_ERROR = -1;
    const STATUS_NO_PROCESS = 0;
    const STATUS_PROCESSING = 1;
    const STATUS_PROCESSED = 2;

    const IS_ERROR = -1;
    const IS_NOT_GROUND_TRUTH = 0;
    const IS_GROUND_TRUTH = 1;

    const IS_NONE_ID              = 0;
    const IS_IMAGE_FACES_ID       = 1;
    const IS_IMAGE_POLITICS_ID    = 2;
    const IS_VOICE_POLITICS_ID    = 3;
    const IS_IMAGE_EROTIC_ID      = 4;
    const IS_VOICE_EROTIC_ID      = 5;
    const IS_VOICE_LICENSE_ID     = 6;
    const IS_IMAGE_BLOODY_ID      = 7;
    const IS_IMAGE_ADS_ID         = 8;
    const IS_IMAGE_CHILD_ABUSE_ID = 9;
    const IS_IMAGE_VNCH_ID        = 10;
    const IS_IMAGE_FLAG_ID        = 11;
    const IS_IMAGE_RELIGION_ID    = 12;

    // nhãn đúng
    const IS_NONE_FIELD              = 'is_none';
    const IS_IMAGE_FACES_FIELD       = 'is_faces';
    const IS_IMAGE_POLITICS_FIELD    = 'is_politics_image';
    const IS_VOICE_POLITICS_FIELD    = 'is_politics_voice';
    const IS_IMAGE_EROTIC_FIELD      = 'is_erotic_image';
    const IS_VOICE_EROTIC_FIELD      = 'is_erotic_voice';
    const IS_VOICE_LICENSE_FIELD     = 'is_license';
    const IS_IMAGE_BLOODY_FIELD      = 'is_bloody_image';
    const IS_IMAGE_ADS_FIELD         = 'is_ads_image';
    const IS_IMAGE_CHILD_ABUSE_FIELD = 'is_child_abuse_image';
    const IS_IMAGE_VNCH_FIELD        = 'is_vnch_image';
    const IS_IMAGE_FLAG_FIELD        = 'is_flag_image';
    const IS_IMAGE_RELIGION_FIELD    = 'is_religion_image';

    // nhãn AI
    const IS_IMAGE_FACES_AI_FIELD       = 'is_image_faces';
    const IS_IMAGE_POLITICS_AI_FIELD    = 'is_image_politics';
    const IS_VOICE_POLITICS_AI_FIELD    = 'is_voice_politics';
    const IS_IMAGE_EROTIC_AI_FIELD      = 'is_image_erotic';
    const IS_VOICE_EROTIC_AI_FIELD      = 'is_voice_erotic';
    const IS_VOICE_LICENSE_AI_FIELD     = 'is_voice_license';
    const IS_IMAGE_BLOODY_AI_FIELD      = 'is_image_bloody';
    const IS_IMAGE_ADS_AI_FIELD         = 'is_image_ads';
    const IS_IMAGE_CHILD_ABUSE_AI_FIELD = 'is_image_child_abuse';
    const IS_IMAGE_VNCH_AI_FIELD        = 'is_image_vnch';
    const IS_IMAGE_FLAG_AI_FIELD        = 'is_image_flag';
    const IS_IMAGE_RELIGION_AI_FIELD    = 'is_image_religion';

    // Nhãn hiển thị
    const IS_NONE_NAME              = 'Không vi phạm';
    const IS_IMAGE_FACES_NAME       = 'Hình ảnh các lãnh đạo cấp cao';
    const IS_IMAGE_POLITICS_NAME    = 'Hình ảnh vi phạm chính trị (Đường lưỡi bò)';
    const IS_VOICE_POLITICS_NAME    = 'Ngôn từ vi phạm chính trị';
    const IS_IMAGE_EROTIC_NAME      = 'Hình ảnh khiêu dâm';
    const IS_VOICE_EROTIC_NAME      = 'Ngôn từ khiêu dâm';
    const IS_VOICE_LICENSE_NAME     = 'Vi phạm bản quyền';
    const IS_IMAGE_BLOODY_NAME      = 'Vi phạm chém giết bạo lực';
    const IS_IMAGE_ADS_NAME         = 'Vi phạm đồ cấm quảng cáo';
    const IS_IMAGE_CHILD_ABUSE_NAME = 'Vi phạm xâm hại trẻ em';
    const IS_IMAGE_VNCH_NAME        = 'Vi phạm Việt Nam Cộng hòa';
    const IS_IMAGE_FLAG_NAME        = 'Hình ảnh vi phạm chính trị (Cờ vàng 3 sọc)';
    const IS_IMAGE_RELIGION_NAME    = 'Vi phạm tôn giáo';

    // Frame AI
    const IS_IMAGE_FACES_DESCRIPTION_AI_FIELD       = 'image_faces_description';
    const IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD    = 'image_politics_description';
    const IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD    = 'voice_politics_description';
    const IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD      = 'image_erotic_description';
    const IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD      = 'voice_erotic_description';
    const IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD     = 'voice_license_description';
    const IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD      = 'image_bloody_description';
    const IS_IMAGE_ADS_DESCRIPTION_AI_FIELD         = 'image_ads_description';
    const IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD = 'image_child_abuse_description';
    const IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD        = 'image_vnch_description';
    const IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD        = 'image_flag_description';
    const IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD    = 'image_religion_description';

    // status AI
    const IMAGE_FACES_STATUS       = 'image_faces_status';
    const IMAGE_POLITICS_STATUS    = 'image_politics_status';
    const VOICE_POLITICS_STATUS    = 'voice_politics_status';
    const IMAGE_EROTIC_STATUS      = 'image_erotic_status';
    const VOICE_EROTIC_STATUS      = 'voice_erotic_status';
    const VOICE_LICENSE_STATUS     = 'voice_license_status';
    const IMAGE_BLOODY_STATUS      = 'image_bloody_status';
    const IMAGE_ADS_STATUS         = 'image_ads_status';
    const IMAGE_CHILD_ABUSE_STATUS = 'image_child_abuse_status';
    const IMAGE_VNCH_STATUS        = 'image_vnch_status';
    const IMAGE_FLAG_STATUS        = 'image_flag_status';
    const IMAGE_RELIGION_STATUS    = 'image_religion_status';

    const GROUND_TRUTH_STATUS_FIELD = [
        self::IMAGE_FACES_STATUS,
        self::IMAGE_POLITICS_STATUS,
        self::VOICE_POLITICS_STATUS,
        self::IMAGE_EROTIC_STATUS,
        self::VOICE_EROTIC_STATUS,
        self::VOICE_LICENSE_STATUS,
        self::IMAGE_BLOODY_STATUS,
        self::IMAGE_ADS_STATUS,
        self::IMAGE_CHILD_ABUSE_STATUS,
        self::IMAGE_VNCH_STATUS,
        self::IMAGE_FLAG_STATUS,
        self::IMAGE_RELIGION_STATUS,
    ];

    const GROUND_TRUTH_ID = [
        self::IS_NONE_ID,
        self::IS_IMAGE_FACES_ID,
        self::IS_IMAGE_POLITICS_ID,
        self::IS_VOICE_POLITICS_ID,
        self::IS_IMAGE_EROTIC_ID,
        self::IS_VOICE_EROTIC_ID,
        self::IS_VOICE_LICENSE_ID,
        self::IS_IMAGE_BLOODY_ID,
        self::IS_IMAGE_ADS_ID,
        self::IS_IMAGE_CHILD_ABUSE_ID,
        self::IS_IMAGE_VNCH_ID,
        self::IS_IMAGE_FLAG_ID,
        self::IS_IMAGE_RELIGION_ID
    ];

    //Nội dung vi phạm lưu trong Database
    const GROUND_TRUTH_FIELD = [
        self::IS_NONE_ID              => self::IS_NONE_FIELD,
        self::IS_IMAGE_FACES_ID       => self::IS_IMAGE_FACES_FIELD,
        self::IS_IMAGE_POLITICS_ID    => self::IS_IMAGE_POLITICS_FIELD,
        self::IS_VOICE_POLITICS_ID    => self::IS_VOICE_POLITICS_FIELD,
        self::IS_IMAGE_EROTIC_ID      => self::IS_IMAGE_EROTIC_FIELD,
        self::IS_VOICE_EROTIC_ID      => self::IS_VOICE_EROTIC_FIELD,
        self::IS_VOICE_LICENSE_ID     => self::IS_VOICE_LICENSE_FIELD,
        self::IS_IMAGE_BLOODY_ID      => self::IS_IMAGE_BLOODY_FIELD,
        self::IS_IMAGE_ADS_ID         => self::IS_IMAGE_ADS_FIELD,
        self::IS_IMAGE_CHILD_ABUSE_ID => self::IS_IMAGE_CHILD_ABUSE_FIELD,
        self::IS_IMAGE_VNCH_ID        => self::IS_IMAGE_VNCH_FIELD,
        self::IS_IMAGE_FLAG_ID        => self::IS_IMAGE_FLAG_FIELD,
        self::IS_IMAGE_RELIGION_ID    => self::IS_IMAGE_RELIGION_FIELD,
    ];

    //Nội dung vi phạm hiển thị trên giao diện web
    const GROUND_TRUTH_NAME = [
        self::IS_NONE_ID              => self::IS_NONE_NAME,
        self::IS_IMAGE_FACES_ID       => self::IS_IMAGE_FACES_NAME,
        self::IS_IMAGE_POLITICS_ID    => self::IS_IMAGE_POLITICS_NAME,
        self::IS_VOICE_POLITICS_ID    => self::IS_VOICE_POLITICS_NAME,
        self::IS_IMAGE_EROTIC_ID      => self::IS_IMAGE_EROTIC_NAME,
        self::IS_VOICE_EROTIC_ID      => self::IS_VOICE_EROTIC_NAME,
        self::IS_VOICE_LICENSE_ID     => self::IS_VOICE_LICENSE_NAME,
        self::IS_IMAGE_BLOODY_ID      => self::IS_IMAGE_BLOODY_NAME,
        self::IS_IMAGE_ADS_ID         => self::IS_IMAGE_ADS_NAME,
        self::IS_IMAGE_CHILD_ABUSE_ID => self::IS_IMAGE_CHILD_ABUSE_NAME,
        self::IS_IMAGE_VNCH_ID        => self::IS_IMAGE_VNCH_NAME,
        self::IS_IMAGE_FLAG_ID        => self::IS_IMAGE_FLAG_NAME,
        self::IS_IMAGE_RELIGION_ID    => self::IS_IMAGE_RELIGION_NAME,
    ];

    // Trạng thái xử lý theo nhãn đúng
    const STATUSES_BY_GROUND_TRUTH = [
        self::IMAGE_FACES_STATUS       => self::IS_IMAGE_FACES_FIELD,
        self::IMAGE_POLITICS_STATUS    => self::IS_IMAGE_POLITICS_FIELD,
        self::VOICE_POLITICS_STATUS    => self::IS_VOICE_POLITICS_FIELD,
        self::IMAGE_EROTIC_STATUS      => self::IS_IMAGE_EROTIC_FIELD,
        self::VOICE_EROTIC_STATUS      => self::IS_VOICE_EROTIC_FIELD,
        self::VOICE_LICENSE_STATUS     => self::IS_VOICE_LICENSE_FIELD,
        self::IMAGE_BLOODY_STATUS      => self::IS_IMAGE_BLOODY_FIELD,
        self::IMAGE_ADS_STATUS         => self::IS_IMAGE_ADS_FIELD,
        self::IMAGE_CHILD_ABUSE_STATUS => self::IS_IMAGE_CHILD_ABUSE_FIELD,
        self::IMAGE_VNCH_STATUS        => self::IS_IMAGE_VNCH_FIELD,
        self::IMAGE_FLAG_STATUS        => self::IS_IMAGE_FLAG_FIELD,
        self::IMAGE_RELIGION_STATUS    => self::IS_IMAGE_RELIGION_FIELD,
    ];

    // Trạng thái xử lý theo nhãn AI
    const STATUSES_BY_GROUND_TRUTH_AI = [
        self::IMAGE_FACES_STATUS       => self::IS_IMAGE_FACES_AI_FIELD,
        self::IMAGE_POLITICS_STATUS    => self::IS_IMAGE_POLITICS_AI_FIELD,
        self::VOICE_POLITICS_STATUS    => self::IS_VOICE_POLITICS_AI_FIELD,
        self::IMAGE_EROTIC_STATUS      => self::IS_IMAGE_EROTIC_AI_FIELD,
        self::VOICE_EROTIC_STATUS      => self::IS_VOICE_EROTIC_AI_FIELD,
        self::VOICE_LICENSE_STATUS     => self::IS_VOICE_LICENSE_AI_FIELD,
        self::IMAGE_BLOODY_STATUS      => self::IS_IMAGE_BLOODY_AI_FIELD,
        self::IMAGE_ADS_STATUS         => self::IS_IMAGE_ADS_AI_FIELD,
        self::IMAGE_CHILD_ABUSE_STATUS => self::IS_IMAGE_CHILD_ABUSE_AI_FIELD,
        self::IMAGE_VNCH_STATUS        => self::IS_IMAGE_VNCH_AI_FIELD,
        self::IMAGE_FLAG_STATUS        => self::IS_IMAGE_FLAG_AI_FIELD,
        self::IMAGE_RELIGION_STATUS    => self::IS_IMAGE_RELIGION_AI_FIELD,
    ];

    // Nhãn đúng theo name
    const GROUND_TRUTH_BY_NAME = [
        self::IS_NONE_NAME              => self::IS_NONE_FIELD,
        self::IS_IMAGE_FACES_NAME       => self::IS_IMAGE_FACES_FIELD,
        self::IS_IMAGE_POLITICS_NAME    => self::IS_IMAGE_POLITICS_FIELD,
        self::IS_VOICE_POLITICS_NAME    => self::IS_VOICE_POLITICS_FIELD,
        self::IS_IMAGE_EROTIC_NAME      => self::IS_IMAGE_EROTIC_FIELD,
        self::IS_VOICE_EROTIC_NAME      => self::IS_VOICE_EROTIC_FIELD,
        self::IS_VOICE_LICENSE_NAME     => self::IS_VOICE_LICENSE_FIELD,
        self::IS_IMAGE_BLOODY_NAME      => self::IS_IMAGE_BLOODY_FIELD,
        self::IS_IMAGE_ADS_NAME         => self::IS_IMAGE_ADS_FIELD,
        self::IS_IMAGE_CHILD_ABUSE_NAME => self::IS_IMAGE_CHILD_ABUSE_FIELD,
        self::IS_IMAGE_VNCH_NAME        => self::IS_IMAGE_VNCH_FIELD,
        self::IS_IMAGE_FLAG_NAME        => self::IS_IMAGE_FLAG_FIELD,
        self::IS_IMAGE_RELIGION_NAME    => self::IS_IMAGE_RELIGION_FIELD
    ];

    // Nhãn AI theo name (ko có IS_NONE_NAME)
    const GROUND_TRUTH_AI_BY_NAME = [
        self::IS_IMAGE_FACES_NAME       => self::IS_IMAGE_FACES_AI_FIELD,
        self::IS_IMAGE_POLITICS_NAME    => self::IS_IMAGE_POLITICS_AI_FIELD,
        self::IS_VOICE_POLITICS_NAME    => self::IS_VOICE_POLITICS_AI_FIELD,
        self::IS_IMAGE_EROTIC_NAME      => self::IS_IMAGE_EROTIC_AI_FIELD,
        self::IS_VOICE_EROTIC_NAME      => self::IS_VOICE_EROTIC_AI_FIELD,
        self::IS_VOICE_LICENSE_NAME     => self::IS_VOICE_LICENSE_AI_FIELD,
        self::IS_IMAGE_BLOODY_NAME      => self::IS_IMAGE_BLOODY_AI_FIELD,
        self::IS_IMAGE_ADS_NAME         => self::IS_IMAGE_ADS_AI_FIELD,
        self::IS_IMAGE_CHILD_ABUSE_NAME => self::IS_IMAGE_CHILD_ABUSE_AI_FIELD,
        self::IS_IMAGE_VNCH_NAME        => self::IS_IMAGE_VNCH_AI_FIELD,
        self::IS_IMAGE_FLAG_NAME        => self::IS_IMAGE_FLAG_AI_FIELD,
        self::IS_IMAGE_RELIGION_NAME    => self::IS_IMAGE_RELIGION_AI_FIELD
    ];

    protected $table = 'video_ground_truth';
    protected $fillable = [
        'video_id',
        'video_playlist_id',
        'name',
        'path',
        'created_by',

        // nhãn đúng
        'is_none',
        'is_faces',
        'is_politics_image',
        'is_politics_voice',
        'is_erotic_image',
        'is_erotic_voice',
        'is_license',
        'is_bloody_image',
        'is_ads_image',
        'is_child_abuse_image',
        'is_vnch_image',
        'is_flag_image',
        'is_religion_image',

        // nhãn AI
        'is_image_faces',
        'is_image_politics',
        'is_voice_politics',
        'is_image_erotic',
        'is_voice_erotic',
        'is_voice_license',
        'is_image_bloody',
        'is_image_ads',
        'is_image_child_abuse',
        'is_image_vnch',
        'is_image_flag',
        'is_image_religion',

        // Frame AI
        'image_faces_description',
        'image_politics_description',
        'voice_politics_description',
        'image_erotic_description',
        'voice_erotic_description',
        'voice_license_description',
        'image_bloody_description',
        'image_ads_description',
        'image_child_abuse_description',
        'image_vnch_description',
        'image_flag_description',
        'image_religion_description',

        // status AI
        'image_faces_status',
        'image_politics_status',
        'voice_politics_status',
        'image_erotic_status',
        'voice_erotic_status',
        'voice_license_status',
        'image_bloody_status',
        'image_ads_status',
        'image_child_abuse_status',
        'image_vnch_status',
        'image_flag_status',
        'image_religion_status',
    ];

    public function playlist()
    {
        return $this->belongsTo(Playlist::class, 'video_playlist_id', 'id');
    }

    public static function scopeIsNoProcess($query)
    {
        return $query->where(function($q) {
            $q->where(self::IMAGE_FACES_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_POLITICS_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::VOICE_POLITICS_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_EROTIC_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::VOICE_EROTIC_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::VOICE_LICENSE_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_BLOODY_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_ADS_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_CHILD_ABUSE_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_VNCH_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_FLAG_STATUS, '!=', self::STATUS_PROCESSED)
                ->orWhere(self::IMAGE_RELIGION_STATUS, '!=', self::STATUS_PROCESSED);
        });
    }

    public static function scopeIsSuccess($query)
    {
        return $query->where(function($q) {
            $q->where(self::IS_IMAGE_FACES_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_POLITICS_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_VOICE_POLITICS_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_EROTIC_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_VOICE_EROTIC_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_VOICE_LICENSE_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_BLOODY_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_ADS_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_CHILD_ABUSE_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_VNCH_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_FLAG_AI_FIELD, '!=', self::IS_ERROR)
                ->where(self::IS_IMAGE_RELIGION_AI_FIELD, '!=', self::IS_ERROR);
        });
    }
}
