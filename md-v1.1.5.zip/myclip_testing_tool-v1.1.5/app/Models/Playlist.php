<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Playlist extends Model
{
    protected $table = 'video_playlist';
    protected $fillable = [ 'name' ];

    public function videos()
    {
        return $this->hasMany(GroundTruth::class, 'video_playlist_id', 'id');
    }
}
