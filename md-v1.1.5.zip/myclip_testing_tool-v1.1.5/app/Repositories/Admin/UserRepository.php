<?php

namespace App\Repositories\Admin;

use App\Models\DepartmentUserMan;
use App\Models\TimeKeeping;
use App\Models\CameraTimeKeeping;
use App\Repositories\Common\DepartmentRepository;
use App\User;
use App\Models\Permission;
use App\Models\PermissionRole;
use App\Repositories\BaseRepository;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use DB;

class UserRepository extends BaseRepository
{
    /**
     * @return string
     */
    public function model()
    {
        return User::class;
    }

    public function updateProfile($arr)
    {
        $user = Auth::user();
        $user->username = $arr['username'];
        $user->email = $arr['email'];
        return $user->save();
    }

    public function changePassword($arr)
    {
        $user = Auth::user();
        $user->password = Hash::make($arr['new_password']);
        return $user->save();
    }
}
