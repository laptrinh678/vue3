<?php

namespace App\Repositories\Common;

use App\Models\GroundTruth;
use App\Repositories\BaseRepository;
use Carbon\Carbon;

class GroundTruthRepository extends BaseRepository
{
    public function model()
    {
        return GroundTruth::class;
    }

    public function getList($keyword = null, $counting = false, $limit = 10, $offset = 0, $orderBy = 'name', $orderType = 'asc', $datePicked = null)
    {
        $query = $this->model->with('playlist')
            ->whereHas('playlist', function ($q) use ($keyword) {
                $q->where('name', 'LIKE', "%$keyword%");
                    // ->orderBy($orderBy == 'playlist.name' ? 'name'  : $orderBy, $orderType);
            });

        if ($counting) {
            return $query->count();
        }

        if ($limit > 0) {
            $query->skip(intval($offset))
                ->take(intval($limit));
        }

        if ($datePicked) {
            $startTime = formatDateTimeUTCCarbon($datePicked[0] . '00:00:00');
            $endTime = formatDateTimeUTCCarbon($datePicked[1] . '23:59:59');
            $query = $query->where('created_at', '>=', $startTime)
                ->where('created_at', '<=', $endTime);
        }

        return $query->get();
    }

    public function store($params)
    {
        $groundTruth = explode(",", $params['ground_truth_id'][0]);

        $this->create([
            'video_id' => $params['video_id'],
            'video_playlist_id' => $params['video_playlist_id'],
            'name' => $params['name'],
            'path' => $params['path'],
            'created_by' => $params['created_by'],
            GroundTruth::IS_NONE_FIELD              => in_array(GroundTruth::IS_NONE_ID, $groundTruth),
            GroundTruth::IS_IMAGE_FACES_FIELD       => in_array(GroundTruth::IS_IMAGE_FACES_ID, $groundTruth),
            GroundTruth::IS_IMAGE_POLITICS_FIELD    => in_array(GroundTruth::IS_IMAGE_POLITICS_ID, $groundTruth),
            GroundTruth::IS_VOICE_POLITICS_FIELD    => in_array(GroundTruth::IS_VOICE_POLITICS_ID, $groundTruth),
            GroundTruth::IS_IMAGE_EROTIC_FIELD      => in_array(GroundTruth::IS_IMAGE_EROTIC_ID, $groundTruth),
            GroundTruth::IS_VOICE_EROTIC_FIELD      => in_array(GroundTruth::IS_VOICE_EROTIC_ID, $groundTruth),
            GroundTruth::IS_VOICE_LICENSE_FIELD     => in_array(GroundTruth::IS_VOICE_LICENSE_ID, $groundTruth),
            GroundTruth::IS_IMAGE_BLOODY_FIELD      => in_array(GroundTruth::IS_IMAGE_BLOODY_ID, $groundTruth),
            GroundTruth::IS_IMAGE_ADS_FIELD         => in_array(GroundTruth::IS_IMAGE_ADS_ID, $groundTruth),
            GroundTruth::IS_IMAGE_CHILD_ABUSE_FIELD => in_array(GroundTruth::IS_IMAGE_CHILD_ABUSE_ID, $groundTruth),
            GroundTruth::IS_IMAGE_VNCH_FIELD        => in_array(GroundTruth::IS_IMAGE_VNCH_ID, $groundTruth),
            GroundTruth::IS_IMAGE_FLAG_FIELD        => in_array(GroundTruth::IS_IMAGE_FLAG_ID, $groundTruth),
            GroundTruth::IS_IMAGE_RELIGION_FIELD    => in_array(GroundTruth::IS_IMAGE_RELIGION_ID, $groundTruth),
        ]);
    }
}
