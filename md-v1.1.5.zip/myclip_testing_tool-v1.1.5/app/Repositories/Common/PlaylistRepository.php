<?php

namespace App\Repositories\Common;

use App\Models\Playlist;
use App\Models\GroundTruth;
use App\Models\Video;
use App\Repositories\BaseRepository;
use Storage;
class PlaylistRepository extends BaseRepository
{
    public function model()
    {
        return Playlist::class;
    }

    public function getList()
    {
        return $this->model->all();
    }

    public function changeCharset($string)
    {
        return mb_convert_encoding($string, "UTF-8", "ISO-8859-1");
    }

    /*Load kết quả quét bằng AI từ bảng video trên server 66 vào bảng video trên server hiện thời*/
    public function updateVideoGoundTruthFromCore()
    {
        /*$videoNoProcessIds = GroundTruth::isNoProcess()->pluck('video_id')->toArray();*/
        $videoNoProcessIds = GroundTruth::pluck('video_id')->toArray();

        if ($videoNoProcessIds) {
            $videos = Video::whereIn('video_id', $videoNoProcessIds)->get();

            foreach ($videos as $video) {
                GroundTruth::where('video_id', $video['video_id'])->update([
                    GroundTruth::IS_IMAGE_FACES_AI_FIELD       => $video[GroundTruth::IS_IMAGE_FACES_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_POLITICS_AI_FIELD    => $video[GroundTruth::IS_IMAGE_POLITICS_AI_FIELD] ?? 0,
                    GroundTruth::IS_VOICE_POLITICS_AI_FIELD    => $video[GroundTruth::IS_VOICE_POLITICS_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_EROTIC_AI_FIELD      => $video[GroundTruth::IS_IMAGE_EROTIC_AI_FIELD] ?? 0,
                    GroundTruth::IS_VOICE_EROTIC_AI_FIELD      => $video[GroundTruth::IS_VOICE_EROTIC_AI_FIELD] ?? 0,
                    GroundTruth::IS_VOICE_LICENSE_AI_FIELD     => $video[GroundTruth::IS_VOICE_LICENSE_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_BLOODY_AI_FIELD      => $video[GroundTruth::IS_IMAGE_BLOODY_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_ADS_AI_FIELD         => $video[GroundTruth::IS_IMAGE_ADS_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD => $video[GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_VNCH_AI_FIELD        => $video[GroundTruth::IS_IMAGE_VNCH_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_FLAG_AI_FIELD        => $video[GroundTruth::IS_IMAGE_FLAG_AI_FIELD] ?? 0,
                    GroundTruth::IS_IMAGE_RELIGION_AI_FIELD    => $video[GroundTruth::IS_IMAGE_RELIGION_AI_FIELD] ?? 0,

                    GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD       => $this->changeCharset($video[GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD    => $this->changeCharset($video[GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD    => $this->changeCharset($video[GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD      => $this->changeCharset($video[GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD      => $this->changeCharset($video[GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD     => $this->changeCharset($video[GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD      => $this->changeCharset($video[GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD         => $this->changeCharset($video[GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD => $this->changeCharset($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD        => $this->changeCharset($video[GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD        => $this->changeCharset($video[GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD]),
                    GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD    => $this->changeCharset($video[GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD]),

                    GroundTruth::IMAGE_FACES_STATUS       => $video[GroundTruth::IMAGE_FACES_STATUS],
                    GroundTruth::IMAGE_POLITICS_STATUS    => $video[GroundTruth::IMAGE_POLITICS_STATUS],
                    GroundTruth::VOICE_POLITICS_STATUS    => $video[GroundTruth::VOICE_POLITICS_STATUS],
                    GroundTruth::IMAGE_EROTIC_STATUS      => $video[GroundTruth::IMAGE_EROTIC_STATUS],
                    GroundTruth::VOICE_EROTIC_STATUS      => $video[GroundTruth::VOICE_EROTIC_STATUS],
                    GroundTruth::VOICE_LICENSE_STATUS     => $video[GroundTruth::VOICE_LICENSE_STATUS],
                    GroundTruth::IMAGE_BLOODY_STATUS      => $video[GroundTruth::IMAGE_BLOODY_STATUS],
                    GroundTruth::IMAGE_ADS_STATUS         => $video[GroundTruth::IMAGE_ADS_STATUS],
                    GroundTruth::IMAGE_CHILD_ABUSE_STATUS => $video[GroundTruth::IMAGE_CHILD_ABUSE_STATUS],
                    GroundTruth::IMAGE_VNCH_STATUS        => $video[GroundTruth::IMAGE_VNCH_STATUS],
                    GroundTruth::IMAGE_FLAG_STATUS        => $video[GroundTruth::IMAGE_FLAG_STATUS],
                    GroundTruth::IMAGE_RELIGION_STATUS    => $video[GroundTruth::IMAGE_RELIGION_STATUS],
                ]);
            }
        }
    }

    // Danh sách kết quả kiểm duyệt chi tiết
    public function getListCensorshipDetail($params, $counting = false, $limit = 10, $offset = 0, $isDev = false)
    {
        $datePicked = $params['datePicked'];
        $keyword = $params['keyword'] ?? null;
        $groundTruthFilter = $params['ground_truth_id'] ?? null;
        $filterResult = $params['valueFilter'] ?? null;

        /*Load kết quả quét bằng AI từ bảng video trên server 66 vào bảng video trên server hiện thời*/
        $this->updateVideoGoundTruthFromCore();

        if ($datePicked) {
            $startTime = formatDateTimeUTCCarbon($datePicked[0] . ' 00:00:00');
            $endTime = formatDateTimeUTCCarbon($datePicked[1] . ' 23:59:59');
        }

        $videos = GroundTruth::with('playlist')
            ->where(function ($q) use ($keyword) {
                $q->where('name', 'LIKE', "%$keyword%")
                    ->orWhere('video_id', $keyword);
            })
            ->whereBetween('created_at', [$startTime, $endTime])
            ->when($groundTruthFilter, function ($q1) use ($groundTruthFilter) {
                foreach ($groundTruthFilter as $key => $groundTruthField) {
                    if ($key == 0) {
                        $q1->where($groundTruthField, 1);
                    } else {
                        $q1->orWhere($groundTruthField, 1);
                    }
                }

                return $q1;
            })
            ->when(!$counting && $limit > 0, function ($q1) use ($offset, $limit) {
                return $q1->skip($offset)->take($limit);
            })
            ->latest()
            ->latest('video_id')
            ->get();

        $data = $this->formatResponse($videos, $isDev);

        $dataFilter = [];

        $isFilter = !empty($filterResult) && $filterResult != -1;

        if ($isFilter) {
            foreach ($data as $item) {
                if ($item['result'] == $filterResult) {
                    $dataFilter[] = $item;
                }
            }
        }

        if ($counting) {
            return $isFilter ? count($dataFilter) : count($data);
        }

        return $isFilter ? $dataFilter : $data;
    }

    // Danh sách kết quả kiểm duyệt chi tiết video đc upload từ Api ngoài
    public function getListCensorshipDetailApi($params, $counting = false, $limit = 10, $offset = 0, $isDev = false)
    {
        $datePicked = $params['datePicked'];
        $keyword = $params['keyword'] ?? null;
        $groundTruthFilter = $params['ground_truth_id'] ?? null;
        $filterResult = $params['valueFilter'] ?? null;

        /*Load kết quả quét bằng AI từ bảng video trên server 66 vào bảng video trên server hiện thời*/
        $this->updateVideoGoundTruthFromCore();

        if ($datePicked) {
            $startTime = formatDateTimeUTCCarbon($datePicked[0] . ' 00:00:00');
            $endTime = formatDateTimeUTCCarbon($datePicked[1] . ' 23:59:59');
        }

        $videos = Video::whereBetween('created_at', [$startTime, $endTime])
            ->where(function ($q) {
                $q->where('is_testing', 0)->orWhereNull('is_testing');
            })
            ->when($keyword, function ($q) use ($keyword) {
                return $q->where('video_id', $keyword);
            })
            ->when($groundTruthFilter, function ($q1) use ($groundTruthFilter) {
                foreach ($groundTruthFilter as $key => $groundTruthField) {
                    if ($key == 0) {
                        $q1->where($groundTruthField, 1);
                    } else {
                        $q1->orWhere($groundTruthField, 1);
                    }
                }

                return $q1;
            })
            ->when(!$counting && $limit > 0, function ($q1) use ($offset, $limit) {
                return $q1->skip($offset)->take($limit);
            })
            ->latest()
            ->latest('video_id')
            ->get();

        $data = $this->formatResponse($videos, $isDev);

        $dataFilter = [];

        $isFilter = !empty($filterResult) && $filterResult != -1;

        if ($isFilter) {
            foreach ($data as $item) {
                if ($item['result'] == $filterResult) {
                    $dataFilter[] = $item;
                }
            }
        }

        if ($counting) {
            return $isFilter ? count($dataFilter) : count($data);
        }

        return $isFilter ? $dataFilter : $data;
    }

    public function formatResponse($videos, $isDev)
    {
        $listVideoDetail = [];

        foreach ($videos as $video) {
            // Lấy ra nhãn đúng của video
            $groundTruth = $this->getGroundTruth($video);

            $resultAI = $this->getResult($video, $groundTruth);

            $row = [
                'playlist_name'            => $video->playlist->name ?? null,
                'id'                       => $video->id,
                'video_id'                 => $video->video_id,
                'name'                     => $video->name,
                'path'                     => str_replace('/storage', '', Storage::disk('public')->url($video->path)),
                'created_at'               => $video->created_at->toDateTime()->format('d/m/Y H:i'),
                'groundTruth'              => $groundTruth,
                'groundTruthAI'            => $resultAI['groundTruthAI'],
                'groundTruthAIFrame'       => $this->formatGroundTruthAIFrame($video, true, false),
                'groundTruthAIFrameArray'  => $this->formatGroundTruthAIFrame($video, true),
                'groundTruthAIFrameSecond' => $this->formatGroundTruthAIFrame($video, false),
                'result'                   => $resultAI['result']
            ];

            if ($isDev) {
                $row['fullGroundTruthAI'] = $resultAI['fullGroundTruthAI'];
                $row['fullGroundTruthAIFrame'] = $this->formatFullGroundTruthAIFrame($video, true, false);
                $row['fullGroundTruthAIFrameArray'] = $this->formatFullGroundTruthAIFrame($video, true);
                $row['fullGroundTruthAIFrameSecond'] = $this->formatFullGroundTruthAIFrame($video, false);
                $row['fullResult'] = $resultAI['fullResult'];
            }

            $listVideoDetail[] = $row;
        }

        return $listVideoDetail;
    }

    // Format lại thời gian vi phạm theo từng nhãn của từng video
    public function addFrameToResult($groundTruthDesc, $isVoiceLicense = false, $isVoicePolitics = false, $isConverTime = true, $isArray = true)
    {
        $timeErr = '?';

        $arrDesc = json_decode($groundTruthDesc, true);


        if ($arrDesc) {
            $groundTruth = [];
            $groundTruthSecond = [];

            foreach ($arrDesc['meta'] as $meta) {
                if ($isVoicePolitics) {
                    $start = isset($meta['beg']) ? $this->formatSecond($meta['beg']) : $timeErr;
                    $startSecond = isset($meta['beg']) ? (int)floor($meta['beg']) : $timeErr;
                } else if ($isVoiceLicense) {
                    $meta = $meta['infringement_summary'][0];
                    $start = isset($meta['start']) ? $this->formatSecond($meta['start']) : $timeErr;
                    $startSecond = isset($meta['start']) ? (int)floor($meta['start']) : $timeErr;
                } else {
                    $start = isset($meta['start']) ? $this->formatSecond($meta['start']) : $timeErr;
                    $startSecond = isset($meta['start']) ? (int)floor($meta['start']) : $timeErr;
                }

                $end = isset($meta['end']) ? $this->formatSecond($meta['end']) : $timeErr;
                $endSecond = isset($meta['end']) ? (int)floor($meta['end']) : $timeErr;

                $groundTruth[] = $start;
                $groundTruth[] = $end;

                $groundTruthSecond[] = $startSecond;
                $groundTruthSecond[] = $endSecond;
            }

            if (!$isArray) {
                return "(" . implode(", ", $groundTruth) . ")";
            }
            return $isConverTime ? $groundTruth : $groundTruthSecond;
        }
    }

    // Lấy thời gian vi phạm của từng video (dev)
    public function formatFullGroundTruthAIFrame($video, $isConverTime = true, $isArray = true)
    {
        $groundTruthAIFrame = [];
        $groundTruthAIFrameSecond = [];

        $isProcessed = $this->checkIsProcessedByGroundTruth($video);

        if (!$isProcessed) {
            $isProcessError = $this->checkIsProcessError($video);
            return $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT;
        }

        if ($video[GroundTruth::IS_IMAGE_FACES_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_POLITICS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_VOICE_POLITICS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD], false, true, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD], false, true, false);
        }
        if ($video[GroundTruth::IS_IMAGE_EROTIC_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD], false, false, false);
        }
        if ($video[GroundTruth::IS_VOICE_EROTIC_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_VOICE_LICENSE_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD], true, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD], true, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_BLOODY_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_ADS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_VNCH_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_FLAG_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_RELIGION_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if (!$isArray) {
            return implode(", ", $groundTruthAIFrame);
        }
        return $isConverTime ? $groundTruthAIFrame : $groundTruthAIFrameSecond;
    }

    // Lấy thời gian vi phạm của từng video
    public function formatGroundTruthAIFrame($video, $isConverTime = true, $isArray = true)
    {
        $groundTruthAIFrame = [];
        $groundTruthAIFrameSecond = [];

        $isProcessed = $this->checkIsProcessedByGroundTruth($video);

        if (!$isProcessed) {
            $isProcessError = $this->checkIsProcessError($video);
            return $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT;
        }

        if ($video[GroundTruth::IS_IMAGE_FACES_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_FACES_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FACES_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_POLITICS_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_POLITICS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_POLITICS_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_VOICE_POLITICS_FIELD] == 1 && $video[GroundTruth::IS_VOICE_POLITICS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD], false, true, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_POLITICS_DESCRIPTION_AI_FIELD], false, true, false);
        }
        if ($video[GroundTruth::IS_IMAGE_EROTIC_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_EROTIC_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_EROTIC_DESCRIPTION_AI_FIELD], false, false, false);
        }
        if ($video[GroundTruth::IS_VOICE_EROTIC_FIELD] == 1 && $video[GroundTruth::IS_VOICE_EROTIC_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_EROTIC_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_VOICE_LICENSE_FIELD] == 1 && $video[GroundTruth::IS_VOICE_LICENSE_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD], true, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_VOICE_LICENSE_DESCRIPTION_AI_FIELD], true, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_BLOODY_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_BLOODY_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_BLOODY_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_ADS_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_ADS_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_ADS_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_VNCH_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_VNCH_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_VNCH_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_FLAG_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_FLAG_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_FLAG_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if ($video[GroundTruth::IS_IMAGE_RELIGION_FIELD] == 1 && $video[GroundTruth::IS_IMAGE_RELIGION_AI_FIELD] == 1) {
            $groundTruthAIFrame[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD], false, false, $isConverTime, $isArray);
            $groundTruthAIFrameSecond[] = $this->addFrameToResult($video[GroundTruth::IS_IMAGE_RELIGION_DESCRIPTION_AI_FIELD], false, false, false);
        }

        if (!$isArray) {
            return implode(", ", $groundTruthAIFrame);
        }
        return $isConverTime ? $groundTruthAIFrame : $groundTruthAIFrameSecond;
    }

    // Format s -> H:i:s
    public function formatSecond($seconds)
    {
        $hours = (int)floor($seconds / 3600);
        $mins = (int)floor($seconds / 60 % 60);
        $secs = (int)floor($seconds % 60);

        return sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
    }

    // Lấy ra nhãn đúng của từng video
    public function getGroundTruth($video)
    {
        $groundTruth = [];

        foreach (GroundTruth::GROUND_TRUTH_BY_NAME as $groundTruthName => $groundTruthField) {
            if ($video[$groundTruthField] == 1) {
                $groundTruth[] = $groundTruthName;
            }
        }

        return implode(", ", $groundTruth);
    }

    // Lấy ra full nhãn AI của từng video
    public function getFullGroundTruthAI($video)
    {
        $fullGroundTruthAI = [];

        if ($video[GroundTruth::IS_NONE_FIELD] == 1) {
            $count = 0;

            foreach (GroundTruth::GROUND_TRUTH_AI_BY_NAME as $groundTruthName => $groundTruthAIField) {
                if ($video[$groundTruthAIField] == 1) {
                    $fullGroundTruthAI[] = $groundTruthName;
                    $count ++;
                }
            }

            if (!$count) {
                $fullGroundTruthAI[] = GroundTruth::IS_NONE_NAME;
            }
        }

        foreach (GroundTruth::GROUND_TRUTH_AI_BY_NAME as $groundTruthName => $groundTruthAIField) {
            if ($video[$groundTruthAIField] == 1) {
                $fullGroundTruthAI[] = $groundTruthName;
            }
        }

        return implode(", ", $fullGroundTruthAI);
    }

    // Lấy ra nhãn AI của từng video, nếu đc gán nhãn đúng thì mới hiển thị nhãn AI
    public function getGroundTruthAI($video)
    {
        $groundTruthAI = [];

        if ($video[GroundTruth::IS_NONE_FIELD] == 1) {
            $count = 0;

            foreach (GroundTruth::GROUND_TRUTH_AI_BY_NAME as $groundTruthName => $groundTruthAIField) {
                if ($video[$groundTruthAIField] == 1) {
                    $groundTruthAI[] = $groundTruthName;
                    $count ++;
                }
            }

            if (!$count) {
                $groundTruthAI[] = GroundTruth::IS_NONE_NAME;
            }
        }

        foreach (GroundTruth::GROUND_TRUTH_AI_BY_NAME as $groundTruthName => $groundTruthAIField) {
            // field nhãn đúng
            $groundTruthField = GroundTruth::GROUND_TRUTH_BY_NAME[$groundTruthName];

            if ($video[$groundTruthField] == 1 && $video[$groundTruthAIField] == 1) {
                $groundTruthAI[] = $groundTruthName;
            }
        }

        return implode(", ", $groundTruthAI);
    }

    // Lấy ra kết quả của từng video
    public function getResult($video, $groundTruth)
    {
        $trueTxt = 'Đúng';
        $falseTxt = 'Sai';

        $isProcessed = $this->checkIsProcessedByGroundTruth($video);

        if ($isProcessed) {
            $groundTruthAI = $this->getGroundTruthAI($video);
            $fullGroundTruthAI = $this->getFullGroundTruthAI($video);

            return [
                'groundTruthAI' => $groundTruthAI,
                'fullGroundTruthAI' => $fullGroundTruthAI,
                'result' => $groundTruth == $groundTruthAI ? $trueTxt : $falseTxt,
                'fullResult' => $groundTruth == $fullGroundTruthAI ? $trueTxt : $falseTxt
            ];
        }

        $isProcessError = $this->checkIsProcessError($video);

        return [
            'groundTruthAI' => $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT,
            'fullGroundTruthAI' => $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT,
            'result' => $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT,
            'fullResult' => $isProcessError ? PROCESSING_ERROR_TXT : PROCESSING_TXT
        ];
    }

    // Danh sách kết quả kiểm duyệt
    public function getListCensorship($keyword = null, $limit = 10, $offset = 0, $orderBy = 'name', $orderType = 'asc', $groupby = null, $datePicked = null)
    {
        /*Load kết quả quét bằng AI từ bảng video trên server 66 vào bảng video trên server hiện thời*/
        $this->updateVideoGoundTruthFromCore();

        if ($datePicked) {
            $startTime = formatDateTimeUTCCarbon($datePicked[0] . '00:00:00');
            $endTime = formatDateTimeUTCCarbon($datePicked[1] . '23:59:59');
        }

        $data = [];

        if (!$groupby) {
            $groupby = GroundTruth::GROUND_TRUTH_ID;
        }

        //Lấy ra danh sách các nội dung vi phạm
        foreach ($groupby as $item) {
            $groupByField = GroundTruth::GROUND_TRUTH_FIELD[$item];
            $groupByName = GroundTruth::GROUND_TRUTH_NAME[$item];

            $query = $this->model
                ->where('name', 'LIKE', "%$keyword%")
                ->when($limit > 0, function ($q) use ($offset, $limit) {
                    return $q->skip(intval($offset))->take(intval($limit));
                })
                ->with(['videos' => function($q) use ($startTime, $endTime, $groupByField) {
                    $q->isSuccess()
                        ->whereBetween('created_at', [$startTime, $endTime])
                        ->where($groupByField, 1);
                }]);

            //Với mỗi vi phạm lấy ra mảng các playlist, với mỗi playlist lấy ra mảng các video của playlist đó
            $data[$groupByName] = $query->get();
        }

        //Tính toán độ chính xác của việc quét video
        $data = $this->calcPrecision($data);

        return [
            'count' => count($data),
            'data' => $data,
        ];
    }

    //Tính toán độ chính xác của việc quét video
    public function calcPrecision($groundTruth)
    {
        $result = [];

        foreach ($groundTruth as $key => $playlists) {
            $ground_truth = '';
            $dataSum = [];

            foreach ($playlists as $playlist) {
                $countVideo = count($playlist->videos);

                // Không có video nào chứa nội dung vi phạm thì bỏ qua playlist hiện tại
                if (!$countVideo) {
                    continue;
                }

                // Lấy số video đúng và số video sai của 1 playlist
                $count = $this->getCountVideo($playlist->videos, $key);
                $countVideoWiththoutError = $countVideo - $count['countError'];

                if ($countVideoWiththoutError == 0) {
                    continue;
                }
                $isProcessed = $count['countTrue'] + $count['countWrong'] == $countVideoWiththoutError;

                $item['ground_truth'] = $ground_truth == $key ? '' : $key;
                $item['name']         = $playlist['name'];
                $item['count_video']  = $countVideoWiththoutError;
                $item['count_true']   = $isProcessed ? $count['countTrue'] : PROCESSING_TXT;
                $item['count_wrong']  = $isProcessed ? $count['countWrong'] : PROCESSING_TXT;
                $item['ratio']        = $isProcessed ? round($count['countTrue'] / $countVideo * 100, 2) . '%' : PROCESSING_TXT;

                $ground_truth = $key;

                array_push($result, $item);
                array_push($dataSum, [
                    'ground_truth' => $item['ground_truth'],
                    'name'         => $item['name'],
                    'count_video'  => $item['count_video'],
                    'count_true'   => $isProcessed ? $count['countTrue'] : PROCESSING_TXT,
                    'count_wrong'  => $isProcessed ? $count['countWrong'] : PROCESSING_TXT
                ]);
            }

            // Tính tổng video theo nội dung vi phạm
            if ($dataSum) {
                $sum = [];
                $sum = $this->getSumVideo($dataSum);

                array_push($result, [
                    'ground_truth' => '',
                    'name'         => 'Tổng',
                    'count_video'  => $sum['countVideo'],
                    'count_true'   => $sum['countTrue'],
                    'count_wrong'  => $sum['countWrong'],
                    'ratio'        => $sum['countTrue'] === PROCESSING_TXT
                                        ? PROCESSING_TXT
                                        : round($sum['countTrue'] / $sum['countVideo'] * 100, 2) . '%'
                ]);
            }
        }

        return $result;
    }

    public function getCountVideo($videos, $key)
    {
        $countTrue = 0;
        $countWrong = 0;
        $countError = 0;

        foreach ($videos as $video) {
            $video = $video->toArray();

            // Kiểm tra xem video này coreAI xử lý có bị lỗi ko
            $isProcessError = $this->checkIsProcessError($video);

            if ($isProcessError) {
                $countError += 1;
                continue;
            }

            // Kiểm tra xem video này đã đc coreAI xử lý hay chưa
            $isProcessed = $this->checkIsProcessedByGroundTruth($video);

            if ($isProcessed) {
                if ($this->checkVideoIsTruth($video, $key)) {
                    $countTrue += 1;
                } else {
                    $countWrong += 1;
                }
            }
        }

        return [
            'countTrue' => $countTrue,
            'countWrong' => $countWrong,
            'countError' => $countError,
        ];
    }

    public function getSumVideo($dataSum)
    {
        $countVideo = 0;
        $countTrue = 0;
        $countWrong = 0;

        foreach ($dataSum as $item) {
            $countVideo += $item['count_video'];

            if (gettype($item['count_true']) !== 'string' && gettype($item['count_wrong']) !== 'string') {
                if (gettype($countTrue) !== 'string' && gettype($countWrong) !== 'string') {
                    $countTrue += $item['count_true'];
                    $countWrong += $item['count_wrong'];
                } else {
                    $countTrue = PROCESSING_TXT;
                    $countWrong = PROCESSING_TXT;
                }
            } else {
                $countTrue = PROCESSING_TXT;
                $countWrong = PROCESSING_TXT;
            }
        }

        return [
            'countVideo' => $countVideo,
            'countTrue'  => $countTrue,
            'countWrong' => $countWrong
        ];
    }

    // Kiểm tra xem kết quả đúng hay sai
    public function checkVideoIsTruth($video, $groundTruth)
    {
        $isVoiceAITrue = false; // AI đánh giá là vi phạm về voice
        $isImageAITrue = false; // AI đánh giá là vi phạm về image

        switch ($groundTruth) {
            case GroundTruth::IS_NONE_NAME:
                if ($video[GroundTruth::IS_IMAGE_FACES_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_FACES_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_POLITICS_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_POLITICS_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_VOICE_POLITICS_FIELD] == 1) {
                    $isVoiceAITrue = $video[GroundTruth::IS_VOICE_POLITICS_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_EROTIC_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_EROTIC_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_VOICE_EROTIC_FIELD] == 1) {
                    $isVoiceAITrue = $video[GroundTruth::IS_VOICE_EROTIC_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_BLOODY_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_BLOODY_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_ADS_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_ADS_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_VNCH_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_VNCH_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_FLAG_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_FLAG_AI_FIELD] == 1;
                } else if ($video[GroundTruth::IS_IMAGE_RELIGION_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_RELIGION_AI_FIELD] == 1;
                } else {
                    $isImageAITrue = false;
                }

                // Khác vs các case trên thì trả về false nghĩa là AI đánh giá video ko vi phạm
                return !$isVoiceAITrue || !$isImageAITrue;
                break;
            //Không dùng VoiceAI để quét trường hợp này
            case GroundTruth::IS_IMAGE_FACES_NAME:
                if ($video[GroundTruth::IS_IMAGE_FACES_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_FACES_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_POLITICS_NAME:
                if ($video[GroundTruth::IS_IMAGE_POLITICS_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_POLITICS_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_VOICE_POLITICS_NAME:
                if ($video[GroundTruth::IS_VOICE_POLITICS_FIELD] == 1) {
                    $isVoiceAITrue = $video[GroundTruth::IS_VOICE_POLITICS_AI_FIELD] == 1;
                }

                return $isVoiceAITrue;
                break;
            case GroundTruth::IS_IMAGE_EROTIC_NAME:
                if ($video[GroundTruth::IS_IMAGE_EROTIC_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_EROTIC_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_VOICE_EROTIC_NAME:
                if ($video[GroundTruth::IS_VOICE_EROTIC_FIELD] == 1) {
                    $isVoiceAITrue = $video[GroundTruth::IS_VOICE_EROTIC_AI_FIELD] == 1;
                }

                return $isVoiceAITrue;
                break;
            case GroundTruth::IS_VOICE_LICENSE_NAME:
                if ($video[GroundTruth::IS_VOICE_LICENSE_FIELD] == 1) {
                    $isVoiceAITrue = $video[GroundTruth::IS_VOICE_LICENSE_AI_FIELD] == 1;
                }

                return $isVoiceAITrue;
                break;
            case GroundTruth::IS_IMAGE_BLOODY_NAME:
                if ($video[GroundTruth::IS_IMAGE_BLOODY_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_BLOODY_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_ADS_NAME:
                if ($video[GroundTruth::IS_IMAGE_ADS_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_ADS_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_CHILD_ABUSE_NAME:
                if ($video[GroundTruth::IS_IMAGE_CHILD_ABUSE_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_CHILD_ABUSE_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_VNCH_NAME:
                if ($video[GroundTruth::IS_IMAGE_VNCH_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_VNCH_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_FLAG_NAME:
                if ($video[GroundTruth::IS_IMAGE_FLAG_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_FLAG_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            case GroundTruth::IS_IMAGE_RELIGION_NAME:
                if ($video[GroundTruth::IS_IMAGE_RELIGION_FIELD] == 1) {
                    $isImageAITrue = $video[GroundTruth::IS_IMAGE_RELIGION_AI_FIELD] == 1;
                }

                return $isImageAITrue;
                break;
            default:
                return false;
        }
    }

    // Video đc gán nhãn đúng là gì thì kiểm tra xem đã quét vi phạm đó hay chưa
    public function checkIsProcessedByGroundTruth($video)
    {
        $result = [];

        if ($video[GroundTruth::IS_NONE_FIELD] == 1) {
            $groundTruth[] = GroundTruth::IS_NONE_NAME;
            return $this->checkIsProcessed($video);
        }

        foreach (GroundTruth::STATUSES_BY_GROUND_TRUTH as $status => $groundTruth) {
            if ($video[$groundTruth] == 1) {
                $result[] = $video[$status] == GroundTruth::STATUS_PROCESSED;
            }
        }

        return !in_array(false, $result);
    }

    // Kiểm tra xem đã quét xong toàn bộ các loại vi phạm chưa
    public function checkIsProcessed($video)
    {
        $statuses = GroundTruth::GROUND_TRUTH_STATUS_FIELD;

        $count = 0;
        foreach ($statuses as $status) {
            if ($video[$status] == GroundTruth::STATUS_PROCESSED) {
                $count ++;
            }
        }

        return $count == count($statuses);
    }

    // Kiểm tra xem có video nào quét lỗi ko
    public function checkIsProcessError($video)
    {
        $statuses = GroundTruth::GROUND_TRUTH_STATUS_FIELD;

        $count = 0;
        foreach ($statuses as $status) {
            if ($video[$status] == GroundTruth::STATUS_PROCESS_ERROR) {
                $count ++;
            }
        }

        return $count > 0;
    }

    public function store($idOrName)
    {
        $isExistsPlaylist = $this->find($idOrName);

        if (!$isExistsPlaylist->count()) {
            $playlist = $this->create(['name' => $idOrName]);
            return $playlist->id;
        }

        return $idOrName;
    }
}
