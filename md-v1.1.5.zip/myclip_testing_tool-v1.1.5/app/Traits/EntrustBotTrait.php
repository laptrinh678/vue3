<?php
namespace App\Traits;

use App\Models\Bot;
use App\Models\RoleUser;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;

trait EntrustBotTrait {
    //Big block of caching functionality.
    public function cachedBots()
    {
        $userPrimaryKey = $this->primaryKey;
        $cacheKey = 'entrust_bots_for_user_'.$this->$userPrimaryKey;
        return Cache::tags(Config::get('entrust.role_user_table'))->remember($cacheKey, Config::get('cache.ttl'), function () {
            return $this->bots()->get();
        });
    }
    // keep other function


    /**
     * Many-to-Many relations with Bots.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function bots()
    {
        $bots = RoleUser::where('user_id', auth()->user()->id)->pluck('bot_id')->toArray();
        return Bot::whereIn('_id', $bots);
    }
}