<?php

namespace App\Traits;

use App\Repositories\ChatBot\BotRepository;

trait PatternUpdatedTrait
{
    protected static function getModelEvents()
    {
        if (isset(static::$capturedEvents)) {
            return static::$capturedEvents;
        }

        return ['created', 'updated', 'deleted'];
    }

    protected static function bootPatternUpdatedTrait()
    {
        foreach (static::getModelEvents() as $event) {
            static::$event(function ($model) {
                if (isset($model->bot_id)){
                    $botRepository = new BotRepository();
                    $bot = $botRepository->find($model->bot_id);
                    if (!empty($bot)) {
                        $bot->need_refresh_patterns = true;
                        $bot->save();
                    }
                }
            });
        }
    }
}
