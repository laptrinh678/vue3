<?php

namespace App;


use App\Models\Department;
use App\Models\Meeting;
use App\Models\Position;
use App\Models\Role;
use App\Models\TimeFrame;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Zizaco\Entrust\Traits\EntrustUserTrait;
use Jenssegers\Mongodb\Eloquent\HybridRelations;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable;
    use EntrustUserTrait;
    use HybridRelations;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username', 'email', 'password','employee_code','gender','birthDay','phone',
        'department_id','position_id','image','display_name', 'status', 'document_number',
        'address', 'time_frame_id', 'image_mask','role_id','parent_lv1_id','parent_lv2_id','parent_lv3_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 'pivot'
    ];

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
    public function departments(){
        return $this->hasOne(Department::class,'id','department_id');
    }
    public function department() {
        return $this->belongsToMany(Department::class, 'department_user_man');
    }
    public function positions(){
        return $this->hasOne(Position::class,'id','position_id');
    }
    public function timeFrames(){
        return $this->hasOne(TimeFrame::class,'id','time_frame_id');
    }

    public function meetings(){
        return $this->belongsToMany(Meeting::class);
    }
}
