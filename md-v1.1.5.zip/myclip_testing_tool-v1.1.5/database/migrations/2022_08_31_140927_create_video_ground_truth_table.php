<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVideoGroundTruthTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('video_ground_truth', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('video_id');
            $table->integer('video_playlist_id');
            $table->string('name');
            $table->string('path');
            $table->integer('created_by');

            // nhãn đúng
            $table->boolean('is_none')->default(0);
            $table->boolean('is_faces')->default(0);
            $table->boolean('is_politics_image')->default(0);
            $table->boolean('is_politics_voice')->default(0);
            $table->boolean('is_erotic_image')->default(0);
            $table->boolean('is_erotic_voice')->default(0);
            $table->boolean('is_license')->default(0);
            $table->boolean('is_bloody_image')->default(0);
            $table->boolean('is_ads_image')->default(0);
            $table->boolean('is_child_abuse_image')->default(0);
            $table->boolean('is_vnch_image')->default(0);
            $table->boolean('is_flag_image')->default(0);
            $table->boolean('is_religion_image')->default(0);

            // nhãn AI
            $table->boolean('is_image_faces')->default(0);
            $table->boolean('is_image_politics')->default(0);
            $table->boolean('is_voice_politics')->default(0);
            $table->boolean('is_image_erotic')->default(0);
            $table->boolean('is_voice_erotic')->default(0);
            $table->boolean('is_voice_license')->default(0);
            $table->boolean('is_image_bloody')->default(0);
            $table->boolean('is_image_ads')->default(0);
            $table->boolean('is_image_child_abuse')->default(0);
            $table->boolean('is_image_vnch')->default(0);
            $table->boolean('is_image_flag')->default(0);
            $table->boolean('is_image_religion')->default(0);

            // Frame AI
            $table->text('image_faces_description');
            $table->text('image_politics_description');
            $table->text('voice_politics_description');
            $table->text('image_erotic_description');
            $table->text('voice_erotic_description');
            $table->text('voice_license_description');
            $table->text('image_bloody_description');
            $table->text('image_ads_description');
            $table->text('image_child_abuse_description');
            $table->text('image_vnch_description');
            $table->text('image_flag_description');
            $table->text('image_religion_description');

            // status AI
            $table->boolean('image_faces_status')->default(0);
            $table->boolean('image_politics_status')->default(0);
            $table->boolean('voice_politics_status')->default(0);
            $table->boolean('image_erotic_status')->default(0);
            $table->boolean('voice_erotic_status')->default(0);
            $table->boolean('voice_license_status')->default(0);
            $table->boolean('image_bloody_status')->default(0);
            $table->boolean('image_ads_status')->default(0);
            $table->boolean('image_child_abuse_status')->default(0);
            $table->boolean('image_vnch_status')->default(0);
            $table->boolean('image_flag_status')->default(0);
            $table->boolean('image_religion_status')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('video_ground_truth');
    }
}
