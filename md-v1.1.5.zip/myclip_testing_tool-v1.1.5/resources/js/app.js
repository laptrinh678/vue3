import jQuery from 'jquery';
window.jQuery = window.$ = jQuery

import Vue from 'vue'
import store from '~/store'
import router from '~/router'
import i18n from '~/plugins/i18n'
import App from '~/components/App'

import '~/plugins'
import '~/components'

import * as VueGoogleMaps from 'vue2-google-maps'

Vue.use(VueGoogleMaps, {
    load: {
      key: 'AIzaSyBqJvun6tfWoyEdElnt5EnCi0ZDiAKqoYo',
      libraries: 'places',
    }
  });

import ElementUI from 'element-ui'
import vi from 'element-ui/lib/locale/lang/vi'
import en from 'element-ui/lib/locale/lang/en'
import la from 'element-ui/lib/locale/lang/th'
import ca from 'element-ui/lib/locale/lang/ca'
import locale from 'element-ui/lib/locale'
let arr = document.cookie.split('; ');
function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
let lang = getCookie('locale')
switch(lang) {
    case "vi":
        locale.use(vi);
        break;
    case "en":
        locale.use(en);
        break;
    case "la":
        locale.use(la);
        break;
    case "ca":
        locale.use(ca);
        break;
    default:
        locale.use(vi);
}

Vue.use(ElementUI)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
    i18n,
    store,
    router,
    ...App,
})
