<template>
    <!-- Accordion tìm kiếm -->
    <div class="m-portlet__body">
        <div class="m-accordion m-accordion--default m-accordion--toggle-arrow" id="m_accordion_5" role="tablist">
            <div class="m-accordion__item m-accordion__item--brand">
                <div class="m-accordion__item-head collapsed" role="tab" id="m_accordion_5_item_3_head"
                        data-toggle="collapse" href="#m_accordion_5_item_3_body" aria-expanded="true">
                    <span class="m-accordion__item-title"> Tìm kiếm nâng cao </span>
                    <span class="m-accordion__item-mode"></span>
                </div>
                <div class="m-accordion__item-body collapse" id="m_accordion_5_item_3_body" role="tabpanel"
                        aria-labelledby="m_accordion_5_item_3_head" data-parent="#m_accordion_5">
                    <div class="m-accordion__item-content">
                        <!-- Tìm kiếm nâng cao -->
                        <slot></slot>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'AdvancedSearch'
    }
</script>
