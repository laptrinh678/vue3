<template>
        <div ref="chart" class="highcharts"></div>
</template>

<script>
    import Highcharts from 'highcharts'
    import ThePanel from "./ThePanel";

    export default {
        name: "AnotherHighcharts",
        props: {
            title: {
                type: String,
                default: ''
            },
            categories: {
                type: Array,
                default: () => []
            },
            series: {
                type: Array,
                default: () => []
            },
            chartType: {
                type: String,
                default: 'pie'
            },
            tooltipFormat: {
                type: String,
                default: ''
            },
            plotOptions: {
                type: Object,
                default: () => {
                }
            },
            seriesClicked: {
                type: Function,
                default: () => {
                }
            },
            hasLegend: {
                type: Boolean,
                default: false,
            }
        },
        components: {ThePanel},
        data() {
            return {
                chart: null
            }
        },
        mounted() {
            this.initChart()
        },
        methods: {
            initChart() {
                let options = {
                    credits: {
                        enabled: false
                    },
                    chart: {
                        backgroundColor: 'transparent',
                        type: this.chartType
                    },
                    // colors: this.colors,
                    title: {
                        text: ''
                    },
                    subtitle: {
                        text: ''
                    },
                    tooltip: {
                        pointFormat: this.tooltipFormat
                    },
                    plotOptions: {
                        series: {
                            cursor: 'pointer',
                            events: {
                                click: this.seriesClicked
                            }
                        }
                    },
                    xAxis: {
                        type: 'category',
                        labels: {
                            style: {
                                fontSize: '13px',
                                fontFamily: 'Verdana, sans-serif'
                            }
                        },
                        // categories: this.categories
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: ''
                        }
                    },
                    legend: {
                        enable: this.hasLegend,
                        itemStyle: {
                            color: '#fff',
                            fontFamily: 'Open Sans',
                            fontWeight: 'normal',
                            showCheckbox: true
                        },
                        itemHoverStyle: {
                            color: '#fff'
                        },
                        useHTML: true,
                        symbolPadding: 0,
                        symbolWidth: 0.1,
                        symbolHeight: 0.1,
                        symbolRadius: 0
                    },
                    series: this.series

                }
                Object.assign(options.plotOptions, this.plotOptions)
                this.chart = Highcharts.chart(this.$refs.chart, options
                );
            }
        },
        watch: {
            series:{
                handler(val) {
                    this.chart.update({
                        series: val
                    })
                },
                deep: true,
            }
        }
    }
</script>

<style>
</style>
