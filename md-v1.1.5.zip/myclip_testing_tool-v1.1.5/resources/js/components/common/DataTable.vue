<template>
    <table class="table table-bordered table-hover display compact responsive row-border"></table>
</template>

<style>
    @import "~datatables.net-bs4/css/dataTables.bootstrap4.min.css";
    @import "~datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css";
</style>

<script>
    import 'datatables.net-bs4'
    import 'datatables.net-responsive-bs4'
    import 'datatables.net-fixedheader-bs4'

    export default {
        name: 'DataTable',
        props: {
            columns: {
                type: Array,
                default: () => []
            },
            columnDefs: {
                type: Array,
                default: () => []
            },
            numIndex: {
                type: Boolean,
                default: true
            },
            url: String,
            actions: {
                type: Array,
                default: () => []
            },
            serverSide: {
                type: Boolean,
                default: true
            },
            processing: {
                type: Boolean,
                default: true
            },
            searching: {
                type: Boolean,
                default: true
            },
            lengthChange: {
                type: Boolean,
                default: true
            },
            ordering: {
                type: Boolean,
                default: true
            },
            orderColumnIndex: {
                type: Number,
                default: 1
            },
            orderType: {
                type: String,
                default: 'asc'
            },
            refresh: {
                type: Boolean,
                default: false
            },
            postData: {
                type: Object,
                default: null
            },
            dom: {
                type: String,
                default: '<\'row\'<\'col-md-6 col-sm-12\'l><\'col-md-6 col-sm-12\'f>r><\'table-scrollable\'t><\'row\'<\'col-md-5 col-sm-12\'i><\'col-md-7 col-sm-12\'p>>'
            },
            searchPlaceholder: {
                type: String,
                default: 'Nhập từ khóa tìm kiếm...'
            },
            bInfo: {
                type: Boolean,
                default: true
            },
            paging: {
                type: Boolean,
                default: true
            }
        },
        data () {
            return {
                table: null

            }
        },
        mounted () {
            this.initTable()
        },
        methods: {
            initTable () {
                $.fn.dataTable.ext.errMode = 'none'
                $.extend($.fn.dataTableExt.oStdClasses, {
                    'sWrapper': 'dataTables_wrapper',
                    'sFilterInput': 'form-control',
                    'sLengthSelect': 'custom-select form-control'
                })
                let defaultConfigs = {
                    dom: this.dom,
                    processing: this.processing,
                    ordering: this.ordering,
                    searching: this.searching,
                    lengthChange: this.lengthChange,
                    serverSide: this.serverSide,
                    responsive: true,
                    fixedHeader: {
                        headerOffset: 70
                    },
                    bInfo: this.bInfo,
                    paging: this.paging,
                    language: {
                        aria: {
                            sortAscending: this.$t('table.sortAscending'),
                            sortDescending: this.$t('table.sortDescending')
                        },
                        processing: '<div class="m-loader m-loader--light m-loader--left"></div><span>&nbsp;&nbsp;&nbsp; ' + this.$t('table.loading') + '...</span>',
                        emptyTable: this.$t('table.no_record'),
                        info: '_START_ - _END_ '+this.$t('table.genitive')+' _TOTAL_ '+this.$t('table.record'),
                        infoEmpty: '',
                        infoFiltered: '',
                        lengthMenu: '_MENU_ '+this.$t('table.record'),
                        search: '',
                        zeroRecords: this.$t('table.no_record'),
                        paginate: {
                            previous: '<i class="la la-angle-left" aria-hidden="true"></i>',
                            next: '<i class="la la-angle-right" aria-hidden="true"></i>',
                            last: 'Cuối',
                            first: 'Đầu'
                        },
                        searchPlaceholder: this.searchPlaceholder
                    },
                    columns: this.tableColumns,
                    columnDefs: this.columnDefs,
                    order: [this.orderColumnIndex, this.orderType],
                    drawCallback: function (settings) {
                        var pagination = $(this).closest('.dataTables_wrapper').find('.dataTables_paginate')
                        pagination.toggle(this.api().page.info().pages > 0)
                    }
                }
                if (this.serverSide) {
                    let _this = this
                    $.extend(defaultConfigs, {
                        ajax: {
                            url: this.url,
                            type: 'POST',
                            dataType: 'json',
                            data: function (d) {
                                return $.extend({}, d, this.postData)
                            }.bind(this),
                            dataSrc: function (res) {
                                _this.$emit('drawCallBack', $(_this.$el).DataTable(defaultConfigs).page.info())
                                return res.data
                            },
                            error: function (e) {
                                if (e.status === 401) {
                                    _this.$message({
                                        message: 'Phiên làm việc của bạn đã hết, vui lòng đăng nhập lại!',
                                        type: 'error'
                                    });
                                    _this.$router.push({name: 'login'})
                                } else {
                                    _this.$message({
                                        message: 'Có lỗi xảy ra, vui lòng thử lại',
                                        type: 'error'
                                    });
                                }
                            }
                        }
                    })
                }

                this.table = $(this.$el).DataTable(defaultConfigs)

                this.initIndexColumn()
                this.registerActions()
            },
            initIndexColumn () {
                if (this.serverSide) {
                    this.table.on('order.dt search.dt draw.dt', function () {
                        var info = this.table.page.info()
                        var start = info.start

                        this.table.column(0, {
                            search: 'applied',
                            order: 'applied'
                        }).nodes().each(function (cell, i) {
                            cell.innerHTML = i + 1 + start
                        })

                        $('.table-action').tooltip();
                    }.bind(this))
                } else {
                    this.table.on('order.dt search.dt draw.dt', function () {
                        this.table.column(0, {
                            search: 'applied',
                            order: 'applied'
                        }).nodes().each(function (cell, i) {
                            cell.innerHTML = i + 1
                        })
                    }.bind(this))
                    this.table.draw()
                }
            },
            registerActions () {
                let vm = this

                if (this.actions.length > 0) {
                    this.actions.forEach(action => {
                        $(this.$el).on(action.type, '[data-action="' + action.name + '"]', function () {
                            $('.table-action').tooltip('hide')

                            let dataId = $(this).data('id')
                            let dataValue = $(this).data('value')

                            var tr = $(this).closest('tr')
                            var data = $(vm.$el).DataTable().row(tr).data()

                            if (dataId) {
                                action.action(dataId, dataValue)
                            } else {
                                action.action(vm.table, data)
                            }
                        })
                    })
                }
            },
            async reinit(){
                $(this.$el).DataTable().destroy()
                // this.table = null
                $(this.$el).empty()
                await this.$nextTick()
                this.initTable()
            },
            reload (keepCurrentPage = true) {
                if (this.table != null) {
                    this.table.ajax.reload(null, !keepCurrentPage)
                }
            },
            destroy(){
                if (this.table != null) {
                    this.table.destroy()
                }
            }
        },
        computed: {
            tableColumns: function () {
                let number = this.$t('form.user.num')
                var columns = this.columns
                if (this.numIndex) {
                    columns.unshift({
                        data: null,
                        title: number,
                        orderable: false,
                        responsivePriority: 1,
                        className: 'tb-number'
                    })
                }
                columns.forEach(column => {
                    if (column.render === undefined) {
                        column.render = $.fn.dataTable.render.text()
                    }
                })
                return columns
            }
        },
        watch: {
            // tableColumns(){
            //     $(this.$el).DataTable().destroy()
            //     this.initTable()
            // }
        },
        destroyed() {
            $(this.$el).DataTable().destroy()
        }
    }
</script>
