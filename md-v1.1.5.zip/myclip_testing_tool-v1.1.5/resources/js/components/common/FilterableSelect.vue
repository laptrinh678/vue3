<template>
    <el-select
        v-model="selected"
        filterable
        placeholder="Chọn chức vụ"
        :filter-method="filterMethod"
        style="width: 100%">
        <el-option
            v-for="item in optionList"
            :key="item.id"
            :label="item.name"
            :value="item.id">
        </el-option>
    </el-select>
</template>

<script>
    import {convertViToEn} from "../../helpers/utilsHelper";

    export default {
        name: "FilterableSelect",
        props: {
            list: {
                type: Array,
                default: []
            },
            listBase: {
                type: Array,
                default: []
            }
        },
        data() {
            return {
                selected: '',
                optionList: []
            }
        },
        updated() {
            this.optionList = this.list
            console.log(this.list)
        },
        watch: {
            selected(val) {
                this.$emit('selected-value', val)
            }
        },
        mounted() {

        },
        methods: {
            filterMethod(query) {
                const keyword = query.trim()
                if (keyword !== '') {
                    setTimeout(() => {
                        this.list = this.listBase.filter(item => {
                            return (
                                convertViToEn(item.name.toLowerCase()).indexOf(
                                    convertViToEn(keyword.toLowerCase())
                                ) > -1
                            )
                        })
                    }, 200)
                } else {
                    this.list = this.listBase
                }
            },
        }

    }
</script>

<style scoped>

</style>
