<template>
  <div
    id="recaptcha"
    class="mb-4"
    data-sitekey="6LdbVz0dAAAAAGbQwCtEY-7CpsFFmP0_KWkSaH-Y"
  ></div>
</template>

<script>
export default {
  name: 'Recaptcha',
  props: {
    submit: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    submit(val) {
      if (val) {
        window.grecaptcha.reset()
        this.check(false)
      }
    }
  },
  mounted() {
    this.render()
  },
  methods: {
    onRecaptchaExpired(t) {
      this.check(t)
    },
    render() {
      if (window.grecaptcha) {
        setTimeout(
          function() {
            if (
              typeof window.grecaptcha === 'undefined' ||
              typeof window.grecaptcha.render === 'undefined'
            ) {
              this.render()
            } else {
              window.grecaptcha.render('recaptcha', {
                callback: (response) => {
                  this.check(response)
                },
                'expired-callback': this.onRecaptchaExpired()
              })
            }
          }.bind(this),
          100
        )
        // window.grecaptcha.render('recaptcha', {
        //   callback: response => {
        //     this.check(response)
        //   },
        //   'expired-callback': this.onRecaptchaExpired
        // })
      }
    },
    check(response) {
      this.$emit('isHuman', response)
    }
  }
}
</script>

<style scoped></style>
