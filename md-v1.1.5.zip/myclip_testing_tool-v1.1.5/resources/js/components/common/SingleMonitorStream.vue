<template>
    <div class="row">
        <div class="col-xl-7" style="padding:0 10px">
            <a href="" class="btn status success">
                <el-tooltip placement="top-end" effect="light">

                        <div  slot="content"> Lần gửi về gần nhất: </div>




                    <el-button>Luồng Restream</el-button>
                </el-tooltip>
            </a>
        </div>
        <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
            <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
            <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
        </div>
    </div>
</template>

<script>
export default {
    name: "SingleMonitorStream"

}
</script>

<style scoped>

</style>
