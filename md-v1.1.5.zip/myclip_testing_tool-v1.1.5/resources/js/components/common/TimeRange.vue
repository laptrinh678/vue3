<template>
    <div>
        <el-form-item
            class="col-md-6"
            :label="startLabel"
            prop="startTime">
            <el-time-picker
                :format='format'
                :value-format='format'
                v-model="startTime"
                :picker-options="{
                              format: startTime,
                              selectableRange:`00:00:00 -${startTime
                              ? startTime + ':00' : '23:59:00'}`
                        }"
                :placeholder="startTimePlaceholder"
            >
            </el-time-picker>
        </el-form-item>
        <el-form-item
            class="col-md-6"
            :label="endLabel"
            prop="endTime">
            <el-time-picker
                :format='format'
                :value-format='format'
                v-model="endTime"
                :picker-options="{
                              format: startTime,
                               selectableRange: `${endTime ?
                                endTime + ':00' : '00:00:00'}-23:59:00`
                        }"
                :placeholder="endTimePlaceholder"
            >
            </el-time-picker>
        </el-form-item>
    </div>
</template>

<script>
    export default {
        name: "TimeRange",
        props: {
            startLabel: {
                type: String,
                default: ''
            },
            endLabel: {
                type: String,
                default: ''
            },
            format: {
                type: String,
                default: ''
            },
            startTime: {
                type: String,
                default: ''
            },
            endTime: {
                type: String,
                default: ''
            },
            startTimePlaceholder: {
                type: String,
                default: ''
            },
            endTimePlaceholder: {
                type: String,
                default: ''
            },

        },
        data() {
            return {
                startTime: '',
                endTime: '',
                rules: {
                    startTime: [
                        {
                            required: true,
                            message: "Thông tin là bắt buộc",
                            trigger: "blur"
                        }
                    ],
                    endTime: [
                        {
                            required: true,
                            message: "Thông tin là bắt buộc",
                            trigger: "blur"
                        }
                    ],
                }
            }
        },
        watch: {
            startTime(value) {
                this.$emit('startTime', value)
            },
            endTime(value) {
                this.$emit('endTime', value)
            }

        }
    }
</script>

<style scoped>

</style>
