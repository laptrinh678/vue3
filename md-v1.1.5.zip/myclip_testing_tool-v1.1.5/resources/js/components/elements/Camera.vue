<template>
    <div>
        <audio v-show="false" id="voiceCamera" controls>
            <source type="audio/ogg"/>
        </audio>
        <div class="camera">
            <vue-web-cam class="cam" ref="webcam":device-id="deviceId" width="100%" height="auto"
                :resolution="resolution" @error="onError" @cameras="onCameras" v-if="!isFigure"/>
            <div v-if="isFigure">
                <img style="width: 100%" :src="img" class="imageCam"/>
            </div>
        </div>
        <div>
            <div class="d-flex justify-content-around container">
                <el-select v-if="selectDeviceDisplay" v-model="camera"
                    style="margin-top: 5px; width: 135px;"
                    :placeholder="$t('form.camera.select_device')">
                    <option style="padding: 0 20px;">-- {{$t('form.camera.select_device')}} --</option>
                    <el-option
                        v-for="device in devices"
                        :key="device.deviceId"
                        :label="device.deviceId"
                        :value="device.deviceId">
                        {{ device.label }}
                    </el-option>
                </el-select>
                <button v-if="capture" class="button" type="button" @click="onCapture" style=" border: solid 1px #0e5ee1; background-color: #0e5ee1;">
                    <i class="el-icon-camera-solid">{{$t('form.user.take_img_btn')}}</i>
                </button>
                <button v-if="!capture" class="button" type="button" @click="changStatus()" style=" border: solid 1px #fea800; background-color: #fea800;">
                    <i class="el-icon-camera-solid">{{$t('form.user.retake_img')}}</i>
                </button>
            </div>
        </div>
    </div>
</template>

<script>
    import {WebCam} from "vue-web-cam";

    export default {
        name: "Camera",
        data() {
            return {
                img: null,
                camera: null,
                deviceId: null,
                devices: [],
                imageCompare: null,
                isFigure: false,
                capture: true,
                resolution: {
                    width: 640,
                    height: 480
                },
                arrIdDevice: null
            }
        },
        props: {
            isChangeCam: {
                type: Boolean,
                default: false
            },
            imageOld: {
                type: String,
                default: null
            },
            selectDeviceDisplay: {
                type: Boolean,
                default: false
            }
        },
        updated() {
            if (this.isFigure === false) {
                this.$refs.webcam.start()
            }
        },
        components: {
            "vue-web-cam": WebCam,
        },
        computed: {
            device: function () {
                return this.devices.find(n => n.deviceId === this.deviceId)
            },
        },
        watch: {
            camera: function (id) {
                this.deviceId = id
            },
            devices: function () {
                const [first] = this.devices
                if (first) {
                    this.camera = first.deviceId
                    this.deviceId = first.deviceId
                }
            },
            imageOld: function (val) {
                this.img = this.imageOld

                if (this.img) {
                    this.isFigure = true
                    this.capture = false
                } else {
                    this.isFigure = false
                    this.capture = true
                }
            }
        },
        methods: {
            getIdCam() {
                let arrDevice = this.devices
                let arrIdDevice = []
                arrDevice.forEach(function (value) {
                    arrIdDevice.push(value.deviceId)
                })
                this.arrIdDevice = arrIdDevice
            },
            getItem() {
                let arr = this.arrIdDevice
                if (arr.length >= 2) {
                    let id = this.arrayRotate()
                    this.onCameraChange(id)
                }
                else
                    this.onCameraChange(arr[0])
            },
            arrayRotate() {
                let arr = this.arrIdDevice
                let count = 99999999999
                count -= arr.length * Math.floor(count / arr.length)
                arr.push.apply(arr, arr.splice(0, count))
                return arr[0]
            },

            //
            changStatus() {
                this.img = null;
                this.isFigure = false;
                this.capture = true;
                this.$emit('changeImage', '');
            },
            onFile(file) {
                console.log(file); // file object
            },
            cancel() {
                this.isFigure = false;
                this.img = null;

            },
            onLoad(dataUri) {
                this.img = dataUri;
                this.isFigure = true;
            },
            onSizeExceeded(size) {

            },
            previewFiles() {
                this.imageCompare = this.$refs.imageCompare.files
            },
            onCapture() {
                this.img = this.$refs.webcam.capture();
                this.isFigure = true;
                this.capture = false;
                this.$emit('changeImage', this.img);
            },
            onStarted(stream) {
                console.log("On Started Event", stream);
            },
            onStopped(stream) {
                console.log("On Stopped Event", stream);
            },
            onStop() {
                this.$refs.webcam.stop();
            },
            onStart() {
                if (this.isFigure === false) {
                    this.$refs.webcam.start();
                }
            },
            onError(error) {
                console.log("On Error Event", error);
            },
            onCameras(cameras) {
                this.devices = cameras
                this.getIdCam()
            },
            onCameraChange(deviceId) {
                this.deviceId = deviceId
                this.camera = deviceId
            }
        }
    }
</script>

<style scoped>
    .camera {
        display: flex;
        justify-content: center;
    }

    .button {
        margin-top: 5px;
        height: 40px;
        width: 140px;
        border-radius: 40px;
        text-decoration: none;
        padding: 8px 16px;
        font-family: Muli;
        text-align: center;
        font-size: 16px;
        font-weight: bold;
        font-stretch: normal;
        font-style: normal;
        line-height: 1.5;
        letter-spacing: normal;
        color: #f2f2f2;
    }
</style>
