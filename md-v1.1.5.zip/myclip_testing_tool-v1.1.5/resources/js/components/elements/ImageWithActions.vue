<template>
    <div>
        <div class="image-block">
                <img class="image" :src="src" :alt="$t('form.camera.image')"/>
                <i v-if="src" class="el-icon-full-screen expand"
                   @click="expand(src)">
                </i>
        </div>

        <el-dialog
            width="fit-content"
            top="5vh"
            :visible.sync="dialogVisible"
            custom-class="image-dialog">
            <img style="max-height: 75vh; max-width: 100%" :src="src" alt=""/>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "ImageWithActions",
        props: {
            src: {
                type: String,
                default: ''
            }
        },
        data: () => {
            return {
                dialogVisible: false
            }
        },
        methods: {
            expand(src) {
                this.dialogVisible = true
            }
        }
    }
</script>

<style scoped>
    .image-block {
        position: relative;
        height: 100%;
    }
    .image-block img {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        max-width: 100%; max-height: 100%;
    }
    .expand {
        color: white;
        top: 8%;
        right: 5%;
        padding: 8px;
        position: absolute;
        cursor: pointer;
    }
    .expand:hover {
        background-color: rgba(0,0,0, 0.4);
        border-radius: 50%;
    }
</style>
