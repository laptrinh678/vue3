<template>
    <div id="no-camera">
        <div id="no-camera_content">
            <img :src="require('~assets/img/design/no-camera.png')" />
            <div id="no-camera-text">{{$t('form.camera.no_image')}}</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "NoImage"
    }
</script>

<style scoped>
    #no-camera-text {
        text-transform: uppercase;
        font-weight: bold;
        margin-top: 10px;
        font-size: 12px;
    }
    #no-camera {
        /*height: 100%;*/
        position: relative;
    }
    #no-camera_content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
    }
</style>
