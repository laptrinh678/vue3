<template>
    <div :class="fileUpload">
        <el-form-item :class="[{requiredField: isRequiredField}, uploadMethod]" :label="label">
            <el-radio-group v-model="isCamera">
                <el-radio :label="0">{{$t('form.user.upload_image')}}</el-radio>
                <el-radio :label="1">{{$t('form.user.take_image')}}</el-radio>
            </el-radio-group>
        </el-form-item>
        <div :class="uploadAction">
            <div v-if="isCamera === 0">
                <el-form-item v-if="!fileUrl">
                    <el-upload
                        drag
                        action="#"
                        :on-change="handlePictureCardPreview"
                        :auto-upload="false"
                        :show-file-list="false">
                        <i class="el-icon-upload"></i>
                        <div class="el-upload__text">
                            {{$t('form.user.pick_img')}} <br/>
                            <em>{{$t('form.user.send_button')}}</em>
                        </div>
                    </el-upload>
                </el-form-item>
                <div v-else id="file-display">
                    <img :src="fileUrl" id="file">
                    <span id="file-close" @click="fileClosed()">
                          <i class="el-icon-close"></i>
                    </span>
                </div>
            </div>
            <div v-else>
                <el-form-item>
                    <camera @changeImage="changeImg" :image-old="image"
                            :select-device-display="selectDeviceDisplay"></camera>
                </el-form-item>
            </div>
            <div
                v-if="isRequiredField && isEmpty"
                class="el-form-item__error">
                {{$t('validate.required')}}
            </div>
        </div>
    </div>
</template>

<script>
import Camera from './Camera.vue'
import { notifyError } from '~/helpers/bootstrap-notify'

export default {
    components: {Camera},
    props: {
        label: {
            type: String,
            default: ''
        },
        isRequiredField: {
            type: Boolean,
            default: false
        },
        selectDeviceDisplay: {
            type: Boolean,
            default: false
        },
        uploadMethod: {
            type: String,
            default: ''
        },
        fileUpload: {
            type: String,
            default: ''
        },
        uploadAction: {
            type: String,
            default: ''
        },
        acceptedFormat: {
            type: Array,
            default: () => ['image/jpeg', 'image/png','video/avi','video/mp4']
        },
        sizeLimit: {
            type: Number,
            default: 20
        },
        image: {
            type: String,
            default: null
        },
        hidden: {
            type: Boolean,
            default: false
        },
        isEmpty: {
            type: Boolean,
            default: false
        }

    },
    data() {
        return {
            isCamera: 1,
            fileUrl: '',
        }
    },
    watch: {
        hidden (val) {
            if (val) {
                this.isCamera = 1
                this.fileUrl = null
            }
        },
        isCamera(val) {
            this.fileUrl = null
            this.$emit('changeImage', '')
        }
    },
    methods: {
        handlePictureCardPreview(file) {
            var $this = this
            const isAcceptedFormat = this.acceptedFormat.some((item) => item === file.raw.type)
            const isLt2M = (file.size / 1024 > 1) && (file.size / 1024 < this.sizeLimit * 1024);
            if (!isAcceptedFormat) {
                notifyError(this.$t('alert.fileFormat'))
            } else if (!isLt2M) {
                notifyError(this.$t('alert.fileSizeLimit'))
            } else {
                if (file) {
                    this.fileUrl = URL.createObjectURL(file.raw);
                    this.getBase64(file.raw).then(res => {
                        $this.$emit('changeImage', res)
                    });
                } else {
                    this.fileUrl = ''
                    this.$emit('changeImage', '')
                }
            }
        },

        getBase64(file) {
            return new Promise(function (resolve, reject) {
                let reader = new FileReader();
                let imgResult = "";
                reader.readAsDataURL(file);
                reader.onload = function () {
                    imgResult = reader.result;
                };
                reader.onerror = function (error) {
                    reject(error);
                };
                reader.onloadend = function () {
                    resolve(imgResult);
                };
            });
        },
        changeImg(img) {
            this.$emit('changeImage', img)
        },

        fileClosed() {
            this.fileUrl = '';
            this.$emit('changeImage', '')
        }
    }
}
</script>
<style scoped>
#file-display {
    position: relative;
}
#file {
    width: 100%;
    border-radius: 10px
}
#file-close {
    position: absolute;
    cursor: pointer;
    right: 0%;
    top: 0%
}
.el-icon-close {
    background-color: white;
    border-radius: 80px
}
</style>
