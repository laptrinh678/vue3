<template>
    <div class="w-100 single-monitor" >
        <ul class="list-style-none">
            <li>
                <div class="row">
                    <div class="col-xl-7" style="padding:0 10px">
                        <a href="" class="btn status success">
                            <el-tooltip placement="top-end" effect="light">
                                <div slot="content">multiple lines</div>
                                <el-button>Luồng RTSP gốc</el-button>
                            </el-tooltip>
                        </a>
                    </div>
                    <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
                        <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
                        <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
                    </div>
                </div>
            </li>
            <li>
                <div class="row">
                    <div class="col-xl-7" style="padding:0 10px">
                        <a href="" class="btn status success">
                            <el-tooltip placement="top-end" effect="light">
                                <div slot="content">multiple lines</div>
                                <el-button>Luồng Restream</el-button>
                            </el-tooltip>
                        </a>
                    </div>
                    <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
                        <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
                        <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
                    </div>
                </div>
            </li>
            <li>
                <div class="row">
                    <div class="col-xl-7"style="padding:0 10px">
                        <a href="" class="btn status warning">
                            <el-tooltip placement="top-end" effect="light">
                                <div slot="content">multiple lines</div>
                                <el-button>Core AI</el-button>
                            </el-tooltip>
                        </a>
                    </div>
                    <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
                        <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
                        <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
                    </div>
                </div>
            </li>
            <li>
                <div class="row">
                    <div class="col-xl-7" style="padding:0 10px">
                        <a href="" class="btn status warning">
                            <el-tooltip placement="top-end" effect="light">
                                <div slot="content">multiple lines</div>
                                <el-button>DeepStream</el-button>
                            </el-tooltip>
                        </a>
                    </div>
                    <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
                        <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
                        <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
                    </div>
                </div>
            </li>
            <li>
                <div class="row">
                    <div class="col-xl-7" style="padding:0 10px">
                        <a href="" class="btn status danger">
                            <el-tooltip placement="top-end" effect="light">
                                <div slot="content">multiple lines</div>
                                <el-button>Event Output</el-button>
                            </el-tooltip>
                        </a>
                    </div>
                    <div class="col-xl-5 d-none d-xl-flex justify-content-xl-end" style="padding-left: 5px">
                        <a href="" class="btn btn-action btn-start" style="margin-right:3px"><span  class="la la-play"></span></a>
                        <a href="" class="btn btn-action btn-stop"><span class="la la-stop"></span></a>
                    </div>
                </div>
            </li>
        </ul>
        <h3 style="text-align: center"> {{cameraName}} </h3>
    </div>
</template>
<script>

export default {
    name: "SingleMonitorCamera",
    data: {
        cameraName : 'Camera 1',
    },
}
</script>
