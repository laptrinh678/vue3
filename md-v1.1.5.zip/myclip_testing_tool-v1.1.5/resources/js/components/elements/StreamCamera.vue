<template>
    <div class="text-center">
       <iframe src="http://172.16.1.49:8080/stream.ogg"></iframe>
    </div>
</template>

<script>
export default {
    name: "StreamCamera",
    mounted() {
        var config = {
            liveSyncDurationCount: 5,
            liveDurationInfinity: true
        }
        if (Hls.isSupported()) {
            var video1 = document.getElementById("camera");
            var hls1 = new Hls(config);
            hls1.on(Hls.Events.MEDIA_ATTACHED, function () {
                hls1.loadSource("http://171.255.199.47/video/video5/index5_.m3u8");
            });
            hls1.attachMedia(video1);
        }
    },
    methods: {}
}
</script>

<style scoped>
video {
    max-width: 100%;
}
</style>
