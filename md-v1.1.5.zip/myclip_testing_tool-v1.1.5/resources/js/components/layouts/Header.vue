<template>
    <header id="m_header" class="m-grid__item m-header " m-minimize-offset="200" m-minimize-mobile-offset="200">
        <div class="m-container m-container--fluid m-container--full-height">
            <div class="m-stack m-stack--ver m-stack--desktop">
                <div class="m-stack__item m-brand " style="padding-left: 60px">
                    <div class="m-stack m-stack--ver m-stack--general">
                        <div class="m-stack__item m-stack__item--middle m-brand__logo">
                            <a href="" class="m-brand__logo-wrapper">
                                <img src="../../../assets/img/design/logo_vtcc.svg" style="width:100%; height: 40px"/>
                            </a>
                        </div>
                        <div class="m-stack__item m-stack__item--middle m-brand__tools">
                            <a href="javascript:;" @click="toggleLeftAside"
                               ref="toggleLeftAside"
                               class="m-brand__icon m-brand__toggler m-brand__toggler--left m--visible-desktop-inline-block">
                                <span></span>
                            </a>
                            <a href="javascript:;" id="m_aside_left_offcanvas_toggle" @click="sideBarResponsive"
                               class="m-brand__icon m-brand__toggler m-brand__toggler--left m--visible-tablet-and-mobile-inline-block">
                                <i class="la la-bars" style="color: #fff; margin-top: 5px"></i>
                                <span></span>
                            </a>
                            <a id="m_aside_header_topbar_mobile_toggle" href="javascript:;" @click="headerResponse"
                               class="m-brand__icon m--visible-tablet-and-mobile-inline-block">
                                <i class="flaticon-more"  style="color: #fff"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="m-stack__item m-stack__item--fluid m-header-head" id="m_header_nav">
                    <button class="m-aside-header-menu-mobile-close  m-aside-header-menu-mobile-close--skin-dark "
                            id="m_aside_header_menu_mobile_close_btn"><i class="la la-close"></i></button>
                    <div
                        id="m_header_menu"
                        class="m-header-menu m-aside-header-menu-mobile m-aside-header-menu-mobile--offcanvas m-header-menu--skin-light m-header-menu--submenu-skin-light
                                m-aside-header-menu-mobile--skin-dark m-aside-header-menu-mobile--submenu-skin-dark"
                    >
                        <h4 class="page-name">{{ routeName }}</h4>
                    </div>
                    <div id="m_header_topbar" class="m-topbar  m-stack m-stack--ver m-stack--general m-stack--fluid">
                        <div class="m-stack__item m-topbar__nav-wrapper">
                            <ul class="m-topbar__nav m-nav m-nav--inline">
                                <profile-actions/>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
</template>

<script>
export default {
    name: 'Header',
    methods: {
        sideBarResponsive() {
            if ($("#m_aside_left").hasClass("m-aside-left--on")) {
                $("#m_aside_left").removeClass('m-aside-left--on')
            } else {
                $("#m_aside_left").addClass('m-aside-left--on')
            }
        },
        headerResponse() {
            if ($("#m_header_topbar").hasClass("header-on")) {
                $("#m_header_topbar").removeClass('header-on')
            } else {
                $("#m_header_topbar").addClass('header-on')
            }
        },
        toggleLeftAside() {
            let bodyClass = 'm-brand--minimize m-aside-left--minimize',
                toggleClass = 'm-brand__toggler--active'

            $('body').toggleClass(bodyClass)
            $(this.$refs.toggleLeftAside).toggleClass(toggleClass)
        },
    },
    computed: {
        // ...mapState({
        //     routeName: state => state.route.meta.title ? state.route.meta.title : state.route.name
        // })
        routeName() {
            const routeName = this.$store.state.route.name;
            if (routeName) {
                return this.$t("menu." + routeName);
            } else return "Chưa có name trong route";
        }
    },
    mounted() {
    }
}
</script>
<style>
.header-on {
    margin-top: 0 !important;
    top: 0 !important;
    -webkit-transition: all 0.3s ease !important;
}
</style>
