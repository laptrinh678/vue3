<template>
    <div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark">
        <div id="m_ver_menu" class="m-aside-menu m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark"
             m-menu-vertical="1" m-menu-scrollable="1" m-menu-dropdown-timeout="500">
            <ul class="m-menu__nav m-menu__nav--dropdown-submenu-arrow">

                <template v-for="menu in menus" v-if="checkPermission(menu)">
                    <router-link v-if="!menu.children" tag="li" class="m-menu__item"
                                 exact-active-class="m-menu__item--active"
                                 :to="{name: menu.route.name}">
                        <a class="m-menu__link">
                            <i class="m-menu__link-icon" :class="menu.icon"></i>
                            <span class="m-menu__link-title">
                                <span class="m-menu__link-wrap">
                                    <span class="m-menu__link-text">{{ menu.title}}</span>
                                </span>
                            </span>
                        </a>
                        <div class="active-cycle-top"></div>
                        <div class="active-cycle-bottom"></div>
                    </router-link>
                    <li class="m-menu__item m-menu__item--submenu" v-else
                        :class="{' m-menu__item--expanded m-menu__item--open' : checkActiveRoute(menu.children, true)}">
                        <a href="javascript:;" class="m-menu__link m-menu__toggle">
                            <i class="m-menu__link-icon" :class="menu.icon"></i>
                            <span class="m-menu__link-text">{{ menu.title }}</span>
                            <i class="m-menu__ver-arrow la la-angle-right"></i>
                        </a>

                        <div class="m-menu__submenu">
                            <span class="m-menu__arrow"></span>
                            <ul class="m-menu__subnav">
                                <router-link tag="li" :to="{name: item.route.name}" v-if="!item.children"
                                             active-class="m-menu__item--active"
                                             class="m-menu__item"
                                             :class="checkActiveSubRoute(item.route.name)"
                                             v-for="item in menu.children"
                                             :key="item.route.name">
                                    <a class="m-menu__link " v-if="checkPermission(item)" >
<!--                                        <i class="m-menu__link-bullet m-menu__link-bullet&#45;&#45;dot"><span></span></i>-->
                                        <span class="m-menu__link-text text-child">{{ item.title }}</span>
                                    </a>
                                    <div class="active-cycle-top"></div>
                                    <div class="active-cycle-bottom"></div>
                                </router-link>

                                <li class="m-menu__item m-menu__item--submenu" v-else
                                    :class="{' m-menu__item--expanded m-menu__item--open' : checkActiveRoute(item.children)}">
                                    <a href="javascript:;" class="m-menu__link m-menu__toggle">
<!--                                        <i class="m-menu__link-bullet m-menu__link-bullet&#45;&#45;dot"><span></span></i>-->
                                        <span class="m-menu__link-text text-child">{{ item.title }}</span>
                                        <i class="m-menu__ver-arrow la la-angle-right"></i>
                                    </a>

                                    <div class="m-menu__submenu">
                                        <span class="m-menu__arrow"></span>
                                        <ul class="m-menu__subnav">
                                            <router-link tag="li" :to="{name: subItem.route.name}"
                                                         active-class="m-menu__item--active"
                                                         class="m-menu__item"
                                                         v-for="subItem in item.children"
                                                         :key="subItem.route.name">
                                                <a class="m-menu__link ">
                                                    <i class="m-menu__link-bullet m-menu__link-bullet--dot"><span></span></i>
                                                    <span class="m-menu__link-text">{{ subItem.title }}</span>
                                                </a>
                                            </router-link>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </li>
                </template>
            </ul>
        </div>
    </div>
</template>

<script>

    import {mapState} from 'vuex'
    import routes from '~/router/routes';
    export default {
        name: 'LeftAside',
        data() {
            let isDev = this.$store.getters['auth/user'] && this.$store.getters['auth/user'].username === 'dev_vtcc'

            return {
                isDev: isDev,
                count : 0,
                menus: []
            }
        },
        mounted() {
            this.menus = [
                {
                    title: 'Kiểm duyệt video',
                    icon: 'la la-clock-o',
                    route: routes.censorship
                },
                {
                    title: 'Kết quả kiểm duyệt',
                    icon: 'la la-clock-o',
                    route: routes.list
                },
                {
                    title: 'Kết quả chi tiết',
                    icon: 'la la-clock-o',
                    route: routes.detail
                },
            ]

            if (this.isDev) {
                this.menus.push({
                    title: 'Kết quả chi tiết (Dev)',
                    icon: 'la la-clock-o',
                    route: routes.detail__dev
                })

                this.menus.push({
                    title: 'Kết quả chi tiết (Api)',
                    icon: 'la la-clock-o',
                    route: routes.detailApi
                })
            }
        },
         beforeUpdate() {
            let $this = this
            this.$root.$on('reload_left_aside',async function  (){
                await this.$store.dispatch('auth/fetchUser')
                $this.$forceUpdate()
            })
        },
        methods: {
            checkActiveSubRoute(routeName) {
                return this.activeRouteName === 'time_config' && routeName === 'time_frame' ? 'm-menu__item--active' : ''
            },
            checkActiveRoute(menu, isRoot) {
                if (isRoot) {
                    let routNames = []

                    menu.forEach(item => {
                        if (item.route) {
                            routNames.push(item.route.name)
                        }

                        if (item.children) {
                            item.children.forEach(o => {
                                if (o.route) {
                                    routNames.push(o.route.name)
                                }
                            })
                        }
                    })

                    if(routNames.indexOf(this.activeRouteName) !== -1){
                        return true
                    }

                    if (this.activeRouteName === 'time_config' && routNames.indexOf('time_frame') !== -1) {
                        return true
                    }
                } else {
                    let index = menu.findIndex(item => {
                        if (!item.route) {
                            return false
                        }

                        return item.route.name === this.activeRouteName
                    })

                    return index !== -1
                }
                return false
            },
            checkPermission(menu) {
                if (menu.permission === undefined)
                    return true
                else {
                    for(let i = 0; i <this.perms.length;i++){
                        if(menu.permission === this.perms[i].name){
                            return true
                        }
                    }
                    return false
                }
            }
        },
        computed: {
            ...mapState({
                activeRouteName: state => state.route.name,
                perms: state => state.auth.perms,
            })
        }
    }
</script>
