import i18n from '~/plugins/i18n';

export const SUCCESS = 0;
export const SUCCESS_201 = 201;
export const SUCCESS_200 = 200;

export const UNCHECK = 0;
export const TAGGED = 1;
export const IGNORE = 3;
export const REVIEWED = 2;
export const UNSUCCESS = 4;
export const NEEDCHANGEVALUE = 5;
export const CHANGEDVALUE = 6;
export const IS_MULTI_CAM = true;
export const LISTPROJECT = {
    WORD: 3,
    POST: 2,
    NER: 1
}
export const LABEL_BACKGROUND = ['CMND','CMND_BACK','CCCD','CCCD_BACK','CMCC','RECEIPT']

export const responseCodes = [
    {
        status  : 422,
        code    : 1,
        message : i18n.t('err_code.invalid')
    },
    {
        status  : 422,
        code    : 2,
        message : i18n.t('err_code.err_face')
    },
    {
        status  : 422,
        code    : 3,
        message : i18n.t('err_code.exits_img')
    },
    {
        status  : 422,
        code    : 4,
        message : i18n.t('err_code.exits_img')
    },
    {
        status  : 422,
        code    : 5,
        message : i18n.t('err_code.not_img')
    },
    {
        status  : 422,
        code    : 6,
        message : i18n.t('err_code.upside')
    },
    {
        status  : 422,
        code    : 7,
        message : i18n.t('err_code.too_face')
    },

    {
        status  : 406,
        code    : 'cannotCreate',
        message :  i18n.t('err_code.exception')
    },
    {
        status  : 500,
        code    : '',
        message : i18n.t('err_code.serve')
    }
]


