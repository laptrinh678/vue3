export default [
    'success',
    'warning',
    'danger',
    'info',
    'primary',
    'secondary',
    'brand',
    'accent',
    'focus',
    'metal',
    'light',
    'default'
]
