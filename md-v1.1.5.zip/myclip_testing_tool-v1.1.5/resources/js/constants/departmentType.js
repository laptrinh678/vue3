let GUEST = 0
let STAFF = 1
let BLACKLIST = 2
import i18n from '~/plugins/i18n'
let departmentTypes = [
    // {
    //     id: GUEST,
    //     value: GUEST,
    //     text: i18n.t('form.user.guest')
    // },
    {
        id: STAFF,
        value: STAFF,
        text: i18n.t('form.user.internal')
    },
    {
        id: BLACKLIST,
        value: BLACKLIST,
        text: i18n.t('form.user.blacklist')
    }
]

export default {departmentTypes}
