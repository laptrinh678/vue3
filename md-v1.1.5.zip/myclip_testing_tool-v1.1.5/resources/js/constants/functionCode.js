let USER_MANAGER = 'user.manager'
let ROLE_MANAGER = 'role.manager'
let FUNC_MANAGER = 'function.manager'
let DEPT_MANAGER = 'department.manager'
let POST_MANAGER = 'position.manager'
let TIME_MANAGER = 'timeframe.manager'
let CAM_CONFIG   = 'camera.config'
let TOT_CONFIG   = 'total.config'
let MEET_MANAGER = 'meeting.manager'
let MEET_TODAY   = 'meeting.today'
let ROOM_MANAGER = 'meetroom.manager'
let TIME_KEEPING = 'time.keeping'
let VIST_MANAGER = 'visitor.manager'
let SECU_MANAGER = 'security.manager'
let WORK_STATICS = 'work.statistic'
let VIST_STATICS = 'visitor.statistic'
let BASE_REPORTS = 'basic.reports'
let ADV_REPORTS  = 'advanced.reports'
let PUBLIC_LOGIN = 'ippublic.login'

let funcList =[
    {
        id: 1,
        value: USER_MANAGER,
        text: USER_MANAGER
    },
    {
        id: 2,
        value: ROLE_MANAGER,
        text: ROLE_MANAGER
    },
    {
        id: 3,
        value: FUNC_MANAGER,
        text: FUNC_MANAGER
    },
    {
        id: 4,
        value: DEPT_MANAGER,
        text: DEPT_MANAGER
    },
    {
        id: 5,
        value: POST_MANAGER,
        text: POST_MANAGER
    },
    {
        id: 6,
        value: TIME_MANAGER,
        text: TIME_MANAGER
    },
    {
        id: 7,
        value: CAM_CONFIG,
        text: CAM_CONFIG
    },
    {
        id: 8,
        value: TOT_CONFIG,
        text: TOT_CONFIG
    },
    {
        id: 9,
        value: MEET_MANAGER,
        text: MEET_MANAGER
    },
    {
        id: 10,
        value: MEET_TODAY,
        text: MEET_TODAY
    },
    {
        id: 11,
        value: ROOM_MANAGER,
        text: ROOM_MANAGER
    },
    {
        id: 12,
        value: TIME_KEEPING,
        text: TIME_KEEPING
    },
    {
        id: 13,
        value: VIST_MANAGER,
        text: VIST_MANAGER
    },
    {
        id: 14,
        value: SECU_MANAGER,
        text: SECU_MANAGER
    },
    {
        id: 15,
        value: WORK_STATICS,
        text: WORK_STATICS
    },
    {
        id: 16,
        value: VIST_STATICS,
        text: VIST_STATICS
    },
    {
        id: 17,
        value: BASE_REPORTS,
        text: BASE_REPORTS
    },
    {
        id: 18,
        value: ADV_REPORTS,
        text: ADV_REPORTS
    },
    {
        id:19,
        value: PUBLIC_LOGIN,
        text: PUBLIC_LOGIN
    }
]

export default {
    funcList,
    USER_MANAGER,
    ROLE_MANAGER,
    FUNC_MANAGER,
    DEPT_MANAGER,
    POST_MANAGER,
    TIME_MANAGER,
    CAM_CONFIG,
    TOT_CONFIG,
    MEET_MANAGER,
    MEET_TODAY,
    ROOM_MANAGER,
    TIME_KEEPING,
    VIST_MANAGER,
    SECU_MANAGER,
    WORK_STATICS,
    VIST_STATICS,
    BASE_REPORTS,
    ADV_REPORTS,
    PUBLIC_LOGIN
}
