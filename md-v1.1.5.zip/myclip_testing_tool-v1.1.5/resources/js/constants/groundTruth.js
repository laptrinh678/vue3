const IS_NONE_ID              = 0;
const IS_IMAGE_FACES_ID       = 1;
const IS_IMAGE_POLITICS_ID    = 2;
const IS_VOICE_POLITICS_ID    = 3;
const IS_IMAGE_EROTIC_ID      = 4;
const IS_VOICE_EROTIC_ID      = 5;
const IS_VOICE_LICENSE_ID     = 6;
const IS_IMAGE_BLOODY_ID      = 7;
const IS_IMAGE_ADS_ID         = 8;
const IS_IMAGE_CHILD_ABUSE_ID = 9;
const IS_IMAGE_VNCH_ID        = 10;
const IS_IMAGE_FLAG_ID        = 11;
const IS_IMAGE_RELIGION_ID    = 12;

const IS_NONE_CODE              = 'is_none';
const IS_IMAGE_FACES_CODE       = 'is_faces';
const IS_IMAGE_POLITICS_CODE    = 'is_politics_image';
const IS_VOICE_POLITICS_CODE    = 'is_politics_voice';
const IS_IMAGE_EROTIC_CODE      = 'is_erotic_image';
const IS_VOICE_EROTIC_CODE      = 'is_erotic_voice';
const IS_VOICE_LICENSE_CODE     = 'is_license';
const IS_IMAGE_BLOODY_CODE      = 'is_bloody_image';
const IS_IMAGE_ADS_CODE         = 'is_ads_image';
const IS_IMAGE_CHILD_ABUSE_CODE = 'is_child_abuse_image';
const IS_IMAGE_VNCH_CODE        = 'is_vnch_image';
const IS_IMAGE_FLAG_CODE        = 'is_flag_image';
const IS_IMAGE_RELIGION_CODE    = 'is_religion_image';

const IS_IMAGE_FACES_CODE_API       = 'is_image_faces'
const IS_IMAGE_POLITICS_CODE_API    = 'is_image_politics'
const IS_VOICE_POLITICS_CODE_API    = 'is_voice_politics'
const IS_IMAGE_EROTIC_CODE_API      = 'is_image_erotic'
const IS_VOICE_EROTIC_CODE_API      = 'is_voice_erotic'
const IS_VOICE_LICENSE_CODE_API     = 'is_voice_license'
const IS_IMAGE_BLOODY_CODE_API      = 'is_image_bloody'
const IS_IMAGE_ADS_CODE_API         = 'is_image_ads'
const IS_IMAGE_CHILD_ABUSE_CODE_API = 'is_image_child_abuse'
const IS_IMAGE_VNCH_CODE_API        = 'is_image_vnch'
const IS_IMAGE_FLAG_CODE_API        = 'is_image_flag'
const IS_IMAGE_RELIGION_CODE_API    = 'is_image_religion'

export const IS_NONE_NAME              = 'Không vi phạm';
export const IS_IMAGE_FACES_NAME       = 'Hình ảnh các lãnh đạo cấp cao';
export const IS_IMAGE_POLITICS_NAME    = 'Hình ảnh vi phạm chính trị (Đường lưỡi bò)';
export const IS_VOICE_POLITICS_NAME    = 'Ngôn từ vi phạm chính trị';
export const IS_IMAGE_EROTIC_NAME      = 'Hình ảnh khiêu dâm';
export const IS_VOICE_EROTIC_NAME      = 'Ngôn từ khiêu dâm';
export const IS_VOICE_LICENSE_NAME     = 'Vi phạm bản quyền';
export const IS_IMAGE_BLOODY_NAME      = 'Vi phạm chém giết bạo lực';
export const IS_IMAGE_ADS_NAME         = 'Vi phạm đồ cấm quảng cáo';
export const IS_IMAGE_CHILD_ABUSE_NAME = 'Vi phạm xâm hại trẻ em';
export const IS_IMAGE_VNCH_NAME        = 'Vi phạm Việt Nam Cộng hòa';
export const IS_IMAGE_FLAG_NAME        = 'Hình ảnh vi phạm chính trị (Cờ vàng 3 sọc)';
export const IS_IMAGE_RELIGION_NAME    = 'Vi phạm tôn giáo';

export const GROUND_TRUTH_LIST = [
    {
        id: IS_NONE_ID,
        name: IS_NONE_NAME,
        code: IS_NONE_CODE
    },
    {
        id: IS_IMAGE_FACES_ID,
        name: IS_IMAGE_FACES_NAME,
        code: IS_IMAGE_FACES_CODE
    },
    {
        id: IS_IMAGE_POLITICS_ID,
        name: IS_IMAGE_POLITICS_NAME,
        code: IS_IMAGE_POLITICS_CODE
    },
    {
        id: IS_IMAGE_FLAG_ID,
        name: IS_IMAGE_FLAG_NAME,
        code: IS_IMAGE_FLAG_CODE
    },
    {
        id: IS_VOICE_POLITICS_ID,
        name: IS_VOICE_POLITICS_NAME,
        code: IS_VOICE_POLITICS_CODE
    },
    {
        id: IS_IMAGE_EROTIC_ID,
        name: IS_IMAGE_EROTIC_NAME,
        code: IS_IMAGE_EROTIC_CODE
    },
    {
        id: IS_VOICE_EROTIC_ID,
        name: IS_VOICE_EROTIC_NAME,
        code: IS_VOICE_EROTIC_CODE
    },
    {
        id: IS_VOICE_LICENSE_ID,
        name: IS_VOICE_LICENSE_NAME,
        code: IS_VOICE_LICENSE_CODE
    },
    {
        id: IS_IMAGE_BLOODY_ID,
        name: IS_IMAGE_BLOODY_NAME,
        code: IS_IMAGE_BLOODY_CODE
    },
    {
        id: IS_IMAGE_ADS_ID,
        name: IS_IMAGE_ADS_NAME,
        code: IS_IMAGE_ADS_CODE
    },
    {
        id: IS_IMAGE_CHILD_ABUSE_ID,
        name: IS_IMAGE_CHILD_ABUSE_NAME,
        code: IS_IMAGE_CHILD_ABUSE_CODE
    },
    {
        id: IS_IMAGE_VNCH_ID,
        name: IS_IMAGE_VNCH_NAME,
        code: IS_IMAGE_VNCH_CODE
    },
    {
        id: IS_IMAGE_RELIGION_ID,
        name: IS_IMAGE_RELIGION_NAME,
        code: IS_IMAGE_RELIGION_CODE
    }
]

export const GROUND_TRUTH_LIST_API = [
    {
        name: IS_IMAGE_FACES_NAME,
        code: IS_IMAGE_FACES_CODE_API
    },
    {
        name: IS_IMAGE_POLITICS_NAME,
        code: IS_IMAGE_POLITICS_CODE_API
    },
    {
        name: IS_IMAGE_FLAG_NAME,
        code: IS_IMAGE_FLAG_CODE_API
    },
    {
        name: IS_VOICE_POLITICS_NAME,
        code: IS_VOICE_POLITICS_CODE_API
    },
    {
        name: IS_IMAGE_EROTIC_NAME,
        code: IS_IMAGE_EROTIC_CODE_API
    },
    {
        name: IS_VOICE_EROTIC_NAME,
        code: IS_VOICE_EROTIC_CODE_API
    },
    {
        name: IS_VOICE_LICENSE_NAME,
        code: IS_VOICE_LICENSE_CODE_API
    },
    {
        name: IS_IMAGE_BLOODY_NAME,
        code: IS_IMAGE_BLOODY_CODE_API
    },
    {
        name: IS_IMAGE_ADS_NAME,
        code: IS_IMAGE_ADS_CODE_API
    },
    {
        name: IS_IMAGE_CHILD_ABUSE_NAME,
        code: IS_IMAGE_CHILD_ABUSE_CODE_API
    },
    {
        name: IS_IMAGE_VNCH_NAME,
        code: IS_IMAGE_VNCH_CODE_API
    },
    {
        name: IS_IMAGE_RELIGION_NAME,
        code: IS_IMAGE_RELIGION_CODE_API
    }
]
