import i18n from '~/plugins/i18n'
export const ROOM_1 = 1

export const options = [
    {
        id: ROOM_1,
        label: i18n.t('meeting_room.label',1)
    },
]
