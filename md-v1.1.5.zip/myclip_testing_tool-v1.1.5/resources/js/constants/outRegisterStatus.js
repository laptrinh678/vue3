let goOutside = [
    {
        id: 0,
        code: 'NOT_SEND',
        text: "Chưa gửi đăng ký",
        class: 'text-info'
    },
    {
        id:1,
        code: 'WAIT_APPROVAL',
        text: "Chờ phê duyệt",
        class: 'text-warning'
    },
    {
        id:2,
        code: 'APPROVED',
        text: "Đã phê duyệt",
        class: 'text-success'
    },
    {
        id:3,
        code: 'REJECTED',
        text: 'Đã từ chối',
        class: 'text-danger'
    }
]

export default {goOutside}

