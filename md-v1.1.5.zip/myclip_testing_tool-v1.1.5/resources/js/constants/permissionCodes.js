let USER_MANAGEMENT = 'user.management'
let GROUP_MANAGEMENT = 'group.management'
let CAMERA_MANAGEMENT = 'camera.management'
let USER_STATISTIC = 'user.statistic'
let MEETING_MANAGEMENT = 'meeting.management'
let SECURITY_MANAGEMENT = 'security.management'
let ROLE_MANAGEMENT = 'role.management'
let PERM_MANAGEMENT = 'perm.management'
let TIMEKEEPING = 'perm.timekeeping'

let permList = [
    {
        id: 1,
        value: USER_MANAGEMENT,
        text: USER_MANAGEMENT
    },
    {
        id: 2,
        value: GROUP_MANAGEMENT,
        text: GROUP_MANAGEMENT
    },
    {
        id: 3,
        value: CAMERA_MANAGEMENT,
        text: CAMERA_MANAGEMENT
    },
    {
        id: 4,
        value: USER_STATISTIC,
        text: USER_STATISTIC
    },
    {
        id: 5,
        value: MEETING_MANAGEMENT,
        text: MEETING_MANAGEMENT
    },
    {
        id: 6,
        value: SECURITY_MANAGEMENT,
        text: SECURITY_MANAGEMENT
    },
    {
        id: 7,
        value: ROLE_MANAGEMENT,
        text: ROLE_MANAGEMENT
    },
    {
        id: 8,
        value: PERM_MANAGEMENT,
        text: PERM_MANAGEMENT
    },
    {
        id: 9,
        value: TIMEKEEPING,
        text: TIMEKEEPING
    }
]

export default {
    permList,
    USER_MANAGEMENT,
    GROUP_MANAGEMENT,
    CAMERA_MANAGEMENT,
    SECURITY_MANAGEMENT,
    USER_STATISTIC,
    MEETING_MANAGEMENT,
    ROLE_MANAGEMENT,
    PERM_MANAGEMENT,
    TIMEKEEPING
}
