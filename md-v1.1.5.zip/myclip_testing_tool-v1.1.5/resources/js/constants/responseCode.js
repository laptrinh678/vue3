export const SUCCESS = 0
export const ERROR = 1
export const QUERY_ERROR = 2
