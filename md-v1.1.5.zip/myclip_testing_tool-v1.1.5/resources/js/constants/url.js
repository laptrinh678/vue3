/*
 |--------------------------------------------------------------------------
 | Auth
 |--------------------------------------------------------------------------
 */
export const API_LOGIN      = '/api/auth/login'
export const API_LOGOUT     = '/api/auth/logout'
export const API_PROFILE    = '/api/auth/me'
export const API_REFRESH    = '/api/auth/refresh'


/*
 |--------------------------------------------------------------------------
 | PROFILE
 |--------------------------------------------------------------------------
 */
export const API_CHANGE_PASSWORD    = '/api/profile/change-password'
export const API_UPDATE_PROFILE     = '/api/profile/update-profile'

/*
 |--------------------------------------------------------------------------
 | ALERT
 |--------------------------------------------------------------------------
 */
export const API_LISTING_ALERT = 'api/alert/listingLastItems'
/*
 |--------------------------------------------------------------------------
 | SERVER URL
 |--------------------------------------------------------------------------
 */
export const SERVER_URL = 'https://171.255.199.47'  //dev_public

/*
 |--------------------------------------------------------------------------
 | VIDEO
 |--------------------------------------------------------------------------
 */
export const API_VIDEO_LIST              = '/api/videos'
export const API_VIDEO_DETAIL            = '/api/videos/detail'
export const API_VIDEO_DETAIL_API        = '/api/videos/detailApi'
export const API_VIDEO_DETAIL_DEV        = '/api/videos/detail__dev'
export const API_VIDEO_STORE             = '/api/videos/store'
export const API_PLAYLIST_LIST           = '/api/videos/playlists'
export const API_VIDEO_EXPORT            = '/api/videos/export'
export const API_VIDEO_DETAIL_EXPORT     = '/api/videos/detail/export'
export const API_VIDEO_DETAIL_EXPORT_DEV = '/api/videos/detail/export__dev'
