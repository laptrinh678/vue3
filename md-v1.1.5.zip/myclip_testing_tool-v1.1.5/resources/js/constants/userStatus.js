export const WORKING = 1
export const RETIRED = 2
export const RESIGNED = 3

export const options = [
    {
        id: WORKING,
        name: "Đang làm việc",
        class: 'text-success'
    },
    {
        id: RETIRED,
        name: 'Nghỉ hưu',
        class: 'text-danger'
    },
    {
        id: RESIGNED,
        name: 'Thôi việc',
        class: 'text-danger'
    }
]
