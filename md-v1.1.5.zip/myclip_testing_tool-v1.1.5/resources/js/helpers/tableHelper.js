export const generateTableAction = (type, action, colorInput, iconInput, titleInput) => {
    let color = '', icon = '', title = ''

    switch
        (type) {
        case 'edit':
            color = 'accent'
            icon = 'la-edit'
            title = titleInput
            break
        case 'delete':
            color = 'danger'
            icon = 'la-trash'
            title = titleInput
            break
        case 'import':
            color = 'success'
            icon = 'la-plus'
            title = titleInput
            break
        case 'detail':
            color = 'warning'
            icon = 'la-file-text'
            title = titleInput
            break
        case 'info':
            color = 'warning'
            icon = 'la-info-circle'
            title = titleInput
            break
        case 'image':
            color = 'accent'
            icon = 'la-image'
            title = titleInput
            break
        default :
            color = colorInput
            icon = iconInput
            title = titleInput
            break
    }

    return '<a href="javascript:;" data-action="' + action + '" ' +
        'class="m-portlet__nav-link btn m-btn m-btn--hover-' + color +
        ' m-btn--icon m-btn--icon-only m-btn--pill table-action" title="' + title + '">\n' +
        '   <i class="la ' + icon + '"></i>\n' +
        '</a>'
}

export const generateImageAction = (action, src, color, title) => {

    var html = '<a href="javascript:;" data-action="' + action + '"' +
        'class="m-portlet__nav-link btn m-btn m-btn--hover-' + color +
        ' m-btn--icon m-btn--icon-only m-btn--pill table-action"' +
        'title="' + title + '">' +
        '<img src="' + src + '" style="max-width: 100%; max-height: 100%"/>' +
        '</a>'
    return html
}

export const generateFrameAction = (data, id, value, action, groundTruth) => {
    let groundTruthArray = groundTruth.split(",")
    let el = ''

    if (typeof data == 'string') {
        return ''
    }
    data.forEach((item, key) => {
        if (item) {
            el += "{"
            item.forEach((item2, key2) => {
                el += `<a href="javascript:;" data-action="${action}" ` +
                        `data-value="${value[key][key2]}"` +
                        `data-id="${id}"` +
                        `class="m-portlet__nav-link table-action"` +
                        `title="${groundTruthArray[key]}"`+
                        `>` +
                        item2 +
                        `</a>`
                if (key2 % 2 == 0) {
                    el += ' - '
                } else {
                    el += key2 === item.length - 1 ? '' : ', '
                }
            })

            el += '}<br />'
        }
    })
    return el
}

export const htmlEscapeEntities = function (d) {
    return typeof d === 'string' ?
        d.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;') :
        d
}




