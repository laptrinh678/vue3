<template>
    <div class="login-page">
        <div class="login-container">
            <div class="login-row">
                <child/>
            </div>
        </div>
    </div>
</template>

<script>
    import Child from "../components/Child";
    export default {
        name: 'auth',
        components: {Child}
    }
</script>
