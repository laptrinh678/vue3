<template>
    <div class="m-grid m-grid--hor m-grid--root m-page">
        <audio v-show="false" id="voice" controls>
            <source type="audio/ogg"/>
        </audio>
        <div class="checkin-wrapper">
                <div class="checkin-content">
                    <child/>
                </div>
        </div>
        <!--<div class="m-grid__item m-grid__item&#45;&#45;fluid m-grid m-grid&#45;&#45;ver-desktop m-grid&#45;&#45;desktop m-body">
            <div class="m-grid__item m-grid__item&#45;&#45;fluid m-wrapper">
                <div class="m-content">
                    <child/>
                </div>
            </div>
        </div>-->
    </div>
</template>

<script>
    import {mapState} from 'vuex'
    export default {
        name: 'MainLayout',
        computed: {
            ...mapState({
                routeName: state => state.route.name
            })
        }
    }
</script>
<style scoped>
    .m-grid__item {
        padding-left: 0px !important;
    }
</style>
