<template>
    <div class="m-grid m-grid--hor m-grid--root m-page ">
      <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
            <div class="m-grid__item m-grid__item--fluid m-wrapper">
                <div class="">
                    <child/>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
    name: 'MainLayout',
    components: {
    },
    computed: {
        ...mapState({
            routeName: state => state.route.name
        })
    }
}
</script>
<style scoped>
.m-grid__item {
    padding-left: 0px !important;
}
</style>
