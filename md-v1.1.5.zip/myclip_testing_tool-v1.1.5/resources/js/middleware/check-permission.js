import store from '~/store'

export default async (to, from, next) => {

    let hasPermission = true

    to.matched.forEach(router => {
        if (router.meta.permission) {
            let index = store.getters['auth/perms'].findIndex(item => item.name === router.meta.permission)

            if (index === -1) {
                hasPermission = false
                return
            }
        }
    })

    if (!hasPermission) {
        console.log('check-perm')
        let defaultUrl = store.getters['auth/check'] ? store.getters['auth/user'].defaultUrl : 'login'
        next({name: defaultUrl})
        // next({ name: 'not_found' })
    }else{
        next()
    }
}
