<template>
    <div class="profile row">
        <div class="col-md-7">
            <div class="m-portlet m-portlet--tab">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <span class="m-portlet__head-icon m--hide">
                                <i class="la la-gear"></i>
                            </span>
                            <h3 class="m-portlet__head-text">
                                {{$t('form.user.basic_infor')}}
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="m-portlet__body">
                    <el-form ref="form" :model="form" :rules="rules" label-width="150px" label-position="top">
                        <div class="row col-md-12">
                            <div class="col-md-6">
                                <el-form-item :label="$t('form.user.username')" prop="username">
                                    <el-tooltip class="input-tooltip" placement="top-end" effect="light" :content="$t('auth.display_name_tooltip')">
                                        <el-input v-model="form.username" @blur="displayNameNoBlur()"></el-input>
                                    </el-tooltip>
                                    <div class="error-message">{{form.errors.get('username')}}</div>
                                </el-form-item>
                            </div>
                            <div class="col-md-6">
                                <el-form-item :label="$t('form.user.email')" prop="email">
                                    <el-input v-model="form.email" @blur="emailNoBlur()" ></el-input>
                                    <div class="error-message">{{form.errors.get('email')}}</div>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>
                <div class="m-portlet__foot m-portlet__foot--fit">
                    <div class="m-form__actions">
                        <button type="button" class="btn btn-secondary" @click="resetProfile('form')">{{ $t('button.cancel')}}</button>
                        <button type="button" class="btn btn-accent" @click="validateForm('form')">
                            {{$t('button.update')}}
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="m-portlet m-portlet--tab">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <span class="m-portlet__head-icon m--hide">
                                <i class="la la-gear"></i>
                            </span>
                            <h3 class="m-portlet__head-text">
                                {{$t('table.repass')}}
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="m-portlet__body" style="height: 546px;">
                    <el-form ref="formPw" :model="formPw" :rules="rules" label-width="150px" label-position="top">
                        <el-form-item :label="$t('form.user.password')" prop="password">
                            <el-input type="password" v-model="formPw.password" autocomplete="off" show-password @focus="isFalse = false" @blur="passwordNoBlur()"></el-input>
                            <div v-if="isFalse" class="error-message">{{formPw.errors.get('password')}}</div>
                        </el-form-item>
                        <el-form-item :label="$t('form.user.new_password')" prop="new_password">
                            <el-tooltip class="input-tooltip" placement="top-end" effect="light" :content="$t('auth.password_tooltip')">
                                <el-input type="password" v-model="formPw.new_password" autocomplete="off" show-password @blur="passwordNoBlur()"></el-input>
                            </el-tooltip>
                            <div class="error-message">{{formPw.errors.get('new_password')}}</div>
                        </el-form-item>
                        <el-form-item :label="$t('form.user.repassword')" prop="re_new_password">
                            <el-input type="password" v-model="formPw.re_new_password"  @blur="passwordNoBlur()" autocomplete="off"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="m-portlet__foot m-portlet__foot--fit">
                    <div class="m-form__actions">
                        <button type="button" class="btn btn-secondary" @click="resetPassword('formPw')">
                            {{ $t('button.cancel')}}
                        </button>
                        <button type="button" class="btn btn-accent" @click="validateFormPw('formPw')">
                            {{$t('button.update')}}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Form from 'vform'
    import { API_UPDATE_PROFILE, API_CHANGE_PASSWORD } from '~/constants/url'
    import { mapState } from 'vuex'
    import { SUCCESS } from '~/constants/code'
    import { notifyTryAgain, notifyUpdateSuccess } from '~/helpers/bootstrap-notify'

    const defaultProfile = {
        username: '',
        email: '',
        image: '',
        status: '',
    }
    const defaultPw = {
        password: '',
        new_password: '',
        re_new_password: ''
    }
    export default {
        components: {},
        layout: 'default',
        middleware: 'auth',
        metaInfo() {
            return {title: "Trang cá nhân"}
        },
        data() {
            let validatePass2 = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error(this.$t('validate.re_enter')));
                } else if (value !== this.formPw.new_password) {
                    callback(new Error(this.$t('validate.repass_notequal')));
                } else {
                    callback();
                }
            }
            let validatePassword = (rule, value, callback) => {
                let pwRule = /^(?=.*[a-z])+(?=.*[A-Z])+(?=.*\d)+(?=.*[$~!#^()@$!%*?&_/\-])[A-Za-z\d$~!#^()@$!%*?&_/\-]{8,100}/
                if (!value.match(pwRule))
                    callback(new Error(this.$t('validate.invalid_pass')))
                else callback()
            }
            let required_infor = this.$t('validate.required')
            let name_max = this.$t('validate.name_max')
            let invalid_email = this.$t('validate.invalid_email')
            let email_max = this.$t('validate.email_max')
            let pass_min = this.$t('validate.pass_min')
            let pass_max = this.$t('validate.pass_max')
            return {
                isFalse: false,
                isEdit: false,
                form: new Form(defaultProfile),
                formPw: new Form(defaultPw),
                pickerOptions: {
                    disabledDate(time) {
                        return time.getTime() > Date.now();
                    }
                },
                rules: {
                    password: [
                        {required: true, message: required_infor, trigger: 'blur'},
                        {min: 8, message: pass_min, trigger: 'blur'},
                        {max: 100, message: pass_max, trigger: 'blur'},
                    ],
                    new_password: [
                        {required: true, message: required_infor, trigger: 'blur'},
                        {min: 8, message: pass_min, trigger: 'blur'},
                        {max: 100, message: pass_max, trigger: 'blur'},
                        {validator: validatePassword, trigger: 'blur'}
                    ],
                    re_new_password: [
                        {required: true, message: required_infor, trigger: 'blur'},
                        {validator: validatePass2, trigger: 'blur'}
                    ],
                    username: [
                        {required: true, message: required_infor, trigger: 'blur'},
                        {max: 100, message: name_max, trigger: 'blur'}
                    ],
                    email: [
                        {type: 'email', message: invalid_email, trigger: ['blur', 'change']},
                        {required: true, message: required_infor, trigger: 'blur'},
                        {max: 45, message: email_max, trigger: 'blur'}
                    ]
                }
            }
        },
        computed: {
            ...mapState({
                users: state => state.auth.user
            })
        },
        mounted(){
            this.initUser()
        },
        methods: {
            initUser(){
                this.form = new Form(this.users)
            },
            validateForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.updateProfile()
                    }
                })
            },
            validateFormPw(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.isFalse = true;
                        this.changePassword();
                    }
                })
            },
            async updateProfile(){
                try {
                    const {data} = await this.form.post(API_UPDATE_PROFILE)
                    if (data.code === SUCCESS) {
                        notifyUpdateSuccess(this.$t('profile.infor'))
                    } else {
                        notifyTryAgain()
                    }
                }
                catch (e) {
                    const {status} = e.response
                    if (status === 422) {
                        notifyTryAgain()
                    }
                }
            },
            async changePassword(){
                try {
                    const {data} = await this.formPw.post(API_CHANGE_PASSWORD)
                    if (data.code === SUCCESS) {
                        notifyUpdateSuccess(this.$t('user.password'))
                        this.formPw = new Form(defaultPw)
                        this.$validator.reset();
                    } else {
                        notifyTryAgain()
                    }
                }
                catch (e) {
                    const {status} = e.response
                    if (status !== 422) {
                        notifyTryAgain()
                    }
                }
            },
            async resetProfile(formName){
                this.$refs[formName].resetFields();
                await this.$store.dispatch('auth/fetchUser')
                this.initUser()
            },
            resetPassword(formName){
                this.$refs[formName].resetFields();
            },
            displayNameNoBlur() {
                this.form.username = this.form.username.trim();
            },
            emailNoBlur() {
                this.form.email = this.form.email.trim();
            },
            passwordNoBlur() {
                this.formPw.password = this.formPw.password.replace(/\s+/g, '')
                this.formPw.new_password = this.formPw.new_password.replace(/\s+/g, '')
                this.formPw.re_new_password = this.formPw.re_new_password.replace(/\s+/g, '')
            }
        }
    }
</script>
