<template>
    <div class="login-wrapper col-xl-5">
        <div style="width: 100%!important ;position:absolute">
            <div id="m_header_topbar" class="m-topbar m-stack  ">
                <div class="m-stack__item">
                    <ul class="m-topbar__nav m-nav m-nav--inline" style="margin-right:20px!important">
                        <language-chosen/>
                    </ul>
                </div>
            </div>
        </div>
        <div class="login-wrapper-container">
            <div class="login-wrapper-logo">
                <img src="../../../assets/img/design/cybervision_logo.png" alt="Timekeeping Logo"/>
            </div>
            <div class="login-wrapper-title">
                <h3><strong>{{ $t('auth.login')}}</strong></h3>
            </div>
            <div class="mb-4" style="height: 30px; width: 280px;">
                <alert :outline="true" color="danger"
                    v-if="form.errors.has('error') || isLoginError">{{message}}
                </alert>
            </div>
            <el-form ref="form" class="login-wrapper-form" :model="form" :rules="rules"
                label-width="150px" label-position="top">
                <el-form-item prop="name">
                    <el-input v-model="form.name" autocomplete="name username"
                        :placeholder="$t('auth.username')"></el-input>
                    <div class="error-message">{{form.errors.get('name')}}</div>
                </el-form-item>
                <el-form-item prop="password">
                    <el-tooltip class="input-tooltip" placement="top-end"
                        effect="light" :content="$t('auth.password_tooltip')">
                        <el-input type="password"  @keyup.enter.native="validateForm('form')" v-model="form.password"
                            :placeholder="$t('auth.password')" autocomplete="password" show-password>
                        </el-input>
                    </el-tooltip>
                    <div class="error-message">{{form.errors.get('password')}}</div>
                </el-form-item>
                <el-checkbox v-model="isRemember" @click="!isRemember">{{$t('auth.rememberpass')}}</el-checkbox>
                <div class="m-login__action mt-3">
                    <el-button class="btn-primary" :loading="isLoading" @click="validateForm('form')">
                        {{$t('auth.login')}}
                    </el-button>
                </div>
            </el-form>
        </div>
    </div>
</template>
<script>

import { API_LOGIN, } from '~/constants/url'
import Form from 'vform'
import CryptoJS from 'crypto-js'

export default {
        name: 'Login',
        middleware: 'guest',
        layout: 'auth',
        transitionName: 'page',
        metaInfo() {
            return {title: this.$t('auth.login')}
        },
        data() {
            return {
                userPerm: 'DELETE',
                message: this.$t('auth.invalid'),
                form: new Form({
                    name: '',
                    password: ''
                }),
                remember: false,
                type: "password",
                isLoginError: false,
                isRemember: false,
                isLoading: false,
                rules: {
                    password: [
                        {required: true, message: this.$t('validate.required'), trigger: 'blur'},
                        {min: 8, message: this.$t('validate.pass_min'), trigger: 'blur'},
                        {max: 100, message: this.$t('validate.pass_max'), trigger: 'blur'},
                    ],
                    name: [
                        {required: true, message: this.$t('validate.required'), trigger: 'blur'},
                        {max: 100, message: this.$t('validate.name_max'), trigger: 'blur'}
                    ],

                }
            }
        },
        watch: {
            form(val) {
                console.log(val)
            }
        },
        mounted(){
            this.getCookie();
        },
        methods: {
            validateForm(formName) {
                this.isLoading = true
                this.$refs[formName].validate((valid) => {
                    if (valid)
                        this.login()
                    else
                        this.isLoading = false
                })
            },
            async login() {
                try{
                    const {data} = await this.form.post(API_LOGIN)
                    if (data.code === 401) {
                        this.isLoading = false
                        this.isLoginError = true
                    }
                    else {
                        await this.$store.dispatch('auth/saveToken', {
                            token: data.access_token,
                            remember: this.isRemember
                        })
                        await this.$store.dispatch('auth/fetchUser')
                        let url = this.$store.getters['auth/user'].defaultUrl
                        if(this.isRemember)
                            this.setCookies(this.form.name,this.form.password,1000)
                        this.$router.push({name: url})
                    }
                    this.isLoading = false
                }
                catch (e){
                    this.isLoading = false
                }
            },
            showPassword() {
                if (this.type === 'password')
                    this.type = 'text'
                else
                    this.type = 'password'
            },
            setCookies(username,password,days){
                let text = CryptoJS.AES.encrypt(password, 'secret key 123');
                let saveDays = new Date();
                saveDays.setTime(Date.now() + 24 * 60 * 60 * 1000 * days);
                window.document.cookie = "username" + "=" + username + ";path=/;expires=" + saveDays.toGMTString()
                window.document.cookie = "password" + "=" + text + ";path=/;expires=" + saveDays.toGMTString()
            },
            getCookie() {
                if (document.cookie.length > 0) {
                    var arr = document.cookie.split('; ')
                    for (var i = 0; i < arr.length; i++) {
                        var arr2 = arr[i].split('=')
                        if (arr2[0] === 'username')
                            this.form.name = arr2[1]
                        else
                            if (arr2[0] === 'password') {
                                var bytes = CryptoJS.AES.decrypt(arr2[1].toString(), 'secret key 123')
                                this.form.password = bytes.toString(CryptoJS.enc.Utf8)
                            }
                    }
                    if(this.form.name !== '')
                        this.isRemember = true
                }
            },
            clearCookie() {
                this.setCookie("", "", 0)
            }
        }
    }
</script>
