<template>

    <div class="login-wrapper col-xl-5">
        <div class="login-wrapper-container" style="width: 350px;text-align:center">
            <div id="refirect-content" style="padding: 50% 0; font-family:Muli;">
                <span id="redirect-title" style="font-size: 30px">
                    <b>Bạn không có quyền truy cập hệ thống</b><br/>
                </span>
            </div>
        </div>
    </div>

</template>

<script>

export default {
    name: 'Redirect',
    layout: 'auth',
    // transitionName: 'page',
    data() {
        return {

        }
    },
    async mounted() {
        await this.$store.dispatch('auth/logout')
    },
    methods: {
    }
}
</script>
<style scoped>
#redirect-title {
    font-size: 16px;
    line-height: 25px;
    color: #ED2B18;

}
#redirect-info {
    line-height: 35px;
}
.redirect-link {
    color: #006BED;
    font-weight: bold;
}
.redirect-link:hover {
    text-decoration: underline;
}
</style>
