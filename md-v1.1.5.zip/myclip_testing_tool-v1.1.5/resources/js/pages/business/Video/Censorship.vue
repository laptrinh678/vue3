<template>
    <div>
        <portlet title="Kiểm duyệt video">
            <template #tool>
                <el-button type="success" icon="el-icon-upload" @click="validateForm" :loading="isLoading">Tải lên</el-button>
            </template>
            <el-form
                ref="form"
                :model="form"
                label-position="top"
            >
                <div class="row col-md-12">
                    <div class="col-md-6 col-xl-5">
                        <el-form-item label="ID video" prop="video_ids">
                            <el-tag
                                v-for="tag in form.video_ids"
                                :key="tag"
                                closable
                                :disable-transitions="false"
                                @close="handleClose(tag)"
                            >
                                {{ tag }}
                            </el-tag>

                            <el-input
                                v-if="inputVisible"
                                class="input-new-tag"
                                v-model="inputValue"
                                ref="saveTagInput"
                                size="mini"
                                @keyup.enter.native="handleInputConfirm"
                                @blur="handleInputConfirm"
                            >
                            </el-input>

                            <el-button
                                v-else
                                class="button-new-tag"
                                size="small"
                                @click="showInput"
                            >
                                + Thêm ID
                            </el-button>

                        </el-form-item>

                        <el-form-item
                            label="Tên danh sách"
                            prop="department_id"
                        >
                            <el-select
                                v-model="form.video_playlist_id"
                                filterable
                                allow-create
                                default-first-option
                                placeholder="Tên danh sách"
                                style="width: 100%"
                            >
                                <el-option
                                    v-for="item in playlists"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item
                            label="Vi phạm"
                            prop="department_id"
                        >
                            <ground-truth-component v-model="form.ground_truth_id" />
                        </el-form-item>

                        <el-upload
                            class="upload-demo-custom"
                            drag
                            action="https://jsonplaceholder.typicode.com/posts/"
                            :on-change="handleChange"
                            :on-exceed="handleExceed"
                            :before-upload="handleBeforeUpload"
                            :file-list="form.fileList"
                            multiple
                            :auto-upload="false"
                            list-type="picture"
                            :limit="limit"
                            accept="video/*"
                        >
                            <i class="el-icon-upload"></i>
                            <div class="el-upload__text">Chọn hoặc kéo thả video ở đây</em></div>

                            <div slot="file" slot-scope="{file}">
                                <audio controls="" :autoplay="false" :src="file.url" id="audio-player"></audio>
                                <span class="el-upload-list__item-actions">
                                    <span @click="handleRemove(file)" class="el-upload-list__item-delete">
                                        <i class="el-icon-delete"></i>
                                    </span>
                                </span>
                            </div>
                        </el-upload>
                    </div>
                    <div class="col-md-6 col-xl-7 list-file">
                        <div v-for="(file, index) in form.fileList">
                            <ul class="el-upload-list el-upload-list--text">
                                <li tabindex="0" class="el-upload-list__item is-ready">
                                    <div class="content">
                                        <span class="pr-3">{{ index + 1 }}.</span>
                                        <video width="35%" controls="controls" :key="file.uid">
                                            <source :src="file.url" type="video/mp4" />
                                        </video>
                                        <span class="pl-3 three-dot-text">{{ file.name }}</span>
                                        <i class="el-icon-close" @click="handleRemove(file)"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </el-form>
        </portlet>
    </div>
</template>

<script>
    import axios from 'axios'
    import cloneDeep from 'lodash/cloneDeep'
    import Portlet from '../../../components/common/Portlet'
    import { API_PLAYLIST_LIST, API_VIDEO_STORE } from '~/constants/url'
    import GroundTruthComponent from './GroundTruthComponent'

    const defaultForm = {
        video_ids: [],
        video_playlist_id: null,
        ground_truth_id: [],
        fileList: []
    }

    export default {
        name: 'VideoCensorship',
        components: { Portlet, GroundTruthComponent },
        data () {
            return {
                limit: 10,
                form: cloneDeep(defaultForm),
                playlists: [],
                isLoading: false,
                inputVisible: false,
                inputValue: ''
            }
        },
        created() {
            this.getListPlaylist()
        },
        methods: {
            handleClose(tag) {
                this.form.video_ids.splice(this.form.video_ids.indexOf(tag), 1);
            },
            showInput() {
                this.inputVisible = true;
                this.$nextTick(() => this.$refs.saveTagInput.$refs.input.focus())
            },
            handleInputConfirm() {
                let inputValue = this.inputValue;
                if (inputValue) {
                    this.form.video_ids.push(inputValue);
                }
                this.inputVisible = false;
                this.inputValue = '';
            },
            async getListPlaylist() {
                try {
                    let repsonse = await axios.get(API_PLAYLIST_LIST)
                    this.playlists = repsonse.data
                } catch (e) {
                    const {status} = e.response

                    if (status === 401) {
                        this.$message({
                            message: 'Phiên làm việc của bạn đã hết, vui lòng đăng nhập lại!',
                            type: 'error'
                        });
                    }
                }
            },
            handleChange(file, fileList) {
                this.form.fileList = fileList.slice(this.limit * -1)
            },
            handleRemove(file) {
                let index = this.form.fileList.findIndex((item) => item.uid === file.uid)
                if (index > -1) {
                    this.form.fileList.splice(index, 1)
                }
            },
            handleExceed(files, fileList) {
                this.$message({
                    message: `Chỉ được tải lên tối đa ${this.limit} video`,
                    type: 'warning'
                });
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`Cancel the transfert of ${ file.name } ?`);
            },
            createFormData () {
                let formData = new FormData();
                let videoIds = this.form.video_ids.toString()

                formData.append('video_ids', videoIds)
                formData.append('video_playlist_id', this.form.video_playlist_id)
                formData.append('ground_truth_id', this.form.ground_truth_id)

                if (this.form.fileList.length) {
                    this.form.fileList.forEach((item) => {
                        formData.append('file[]', item.raw)
                    })
                }

                return formData
            },
            validateForm() {
                if (!this.form.video_playlist_id) {
                    this.$message({
                        message: 'Vui lòng chọn tên danh sách.',
                        type: 'warning'
                    });
                } else if (!this.form.ground_truth_id.length) {
                    this.$message({
                        message: 'Vui lòng chọn vi phạm.',
                        type: 'warning'
                    });
                } else if (!this.form.fileList.length) {
                    this.$message({
                        message: 'Vui lòng chọn video',
                        type: 'warning'
                    });
                } else {
                    this.submitUpload()
                }
            },
            async submitUpload() {
                let config = {
                    header : {
                        'Content-Type' : 'multipart/form-data'
                    }
                }
                let form = this.createFormData()

                try {
                    this.isLoading = true
                    let result = await axios.post(API_VIDEO_STORE, form, config)

                    if (result.data.code === 201) {
                        this.$message({
                            message: `Upload thành công`,
                            type: 'success'
                        })
                        this.getListPlaylist()
                        this.clearData()
                    } else {
                        this.$message({
                            message: `Có lỗi xảy ra, vui lòng thử lại`,
                            type: 'error'
                        })
                    }
                    this.isLoading = false
                } catch (e) {
                    this.$message({
                        message: `Có lỗi xảy ra, vui lòng thử lại`,
                        type: 'error'
                    })
                    this.isLoading = false
                    console.log('err api: ', e)
                }
            },
            clearData() {
                this.form = cloneDeep(defaultForm)
            },
            handleBeforeUpload(file) {
                console.log('file: ', file);
                const isMp4 = file.type === "video/mp4";
                //Limit the maximum file size to 300m
                const isLt2M = file.size / 1024 / 1024 < 300;

                if (!isMp4) {
                    this.$message({
                        message: 'Chỉ chấp nhận video định dạng mp4',
                        type: 'warning'
                    });
                }
                if (!isLt2M) {
                    this.$message({
                        message: 'Chỉ chấp nhận video dung lượng tối đa 300mb',
                        type: 'warning'
                    });
                }
                return isMp4 && isLt2M;
            },
        }
    }
</script>

<style lang="scss">
    .upload-demo-custom {
        .el-upload {
            width: 100%;
            .el-upload-dragger {
                width: 100%;
            }
        }
        .el-upload-list {
            display: none;
        }
    }

    .list-file {
        max-height: calc(100vh - 370px);
        overflow-y: auto;

        .el-upload-list__item {
            .content {
                position: relative;
                display: flex;
                align-items: center;
            }
            i {
                display: none;
            }
            &:hover i {
                position: absolute;
                top: 5px;
                right: 5px;
                display: inline-block;
            }
        }
    }

    .three-dot-text {
        display: inline-block;
        width: 180px;
        white-space: nowrap;
        overflow: hidden !important;
        text-overflow: ellipsis;
    }

    .el-tag {
        margin-right: 10px;
    }
    .button-new-tag {
        border-color: #409EFF;
        color: #409EFF;
        height: 32px;
        line-height: 30px;
        padding-top: 0;
        padding-bottom: 0;
    }
    .input-new-tag {
        width: 90px;
        vertical-align: bottom;
    }
</style>
