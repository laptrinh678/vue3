<template>
    <div>
        <portlet title="Kết quả chi tiết kiểm duyệt video">
            <template #tool>
                <el-button
                    type="success"
                    icon="el-icon-download"
                    :loading="isLoading"
                    @click="exportExcel()"
                >
                    Xuất báo cáo
                </el-button>
            </template>

            <div class="row mb-4">
                <div class="col-md-12">
                    <ground-truth-component v-model="postData.ground_truth_id" isDetail/>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-md-6">
                    <el-date-picker
                        v-model="postData.datePicked"
                        type="daterange"
                        align="center"
                        :start-placeholder="$t('table.start')"
                        :end-placeholder="$t('table.end')"
                        :picker-options="pickerOptions"
                        fomat="dd-MM-yyyy"
                        value-format="dd-MM-yyyy"
                    > </el-date-picker>
                </div>

                <div class="col-md-2"></div>

                <!-- <div class="col-md-1"></div>

                <div class="col-md-2">
                    <el-select v-model="postData.valueFilter" placeholder="Lọc kết quả">
                        <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>

                <div class="col-md-3"> -->
                <div class="col-md-4">
                    <el-input
                        v-model="postData.keyword"
                        placeholder="Nhập tiêu đề video"
                        clearable
                    >
                        <i slot="prefix" class="el-input__icon el-icon-search"></i>
                    </el-input>
                </div>
            </div>

            <data-table
                ref="table"
                :columns="columns"
                :column-defs="columnDefs"
                :url="listingUrl"
                :post-data="postData"
                :searching="false"
                :order-column-index="1"
                order-type="asc"
                @drawCallBack="callBackTable"
                :actions="actions"
            />
        </portlet>
    </div>
</template>

<script>
    import moment from 'moment'
    import { debounce } from 'lodash'
    import axios from 'axios'
    import { API_VIDEO_DETAIL_DEV, API_VIDEO_DETAIL_EXPORT_DEV } from "~/constants/url"
    import { generateFrameAction } from '~/helpers/tableHelper'
    import { downloadFile } from '~/helpers/downloadFile'
    import Form from 'vform'
    import Portlet from "~/components/common/Portlet"
    import DataTable from "~/components/common/DataTable"
    import GroundTruthComponent from './GroundTruthComponent'

    const formSearch = {
        datePicked: [
            // moment().subtract(7, "months").format('DD-MM-YYYY'),
            moment().startOf('month').format('DD-MM-YYYY'),
            moment().endOf('day').format('DD-MM-YYYY')
        ],
        ground_truth_id: [],
        keyword: '',
        valueFilter: null
    }

    export default {
        name: 'DetailDev',
        components: {
            DataTable,
            Portlet,
            GroundTruthComponent
        },
        data(vm) {
            let today = this.$t('table.today')
            let toweek = this.$t('table.toweek')
            let tomonth = this.$t('table.tomonth')
            return {
                listingUrl: API_VIDEO_DETAIL_DEV,
                columnDefs: [
                    {
                        targets: [1, 2, 3, 4, 5, 6, 7, 8, 9],
                        sortable: false
                    },
                ],
                columns: [
                    {
                        data: 'playlist_name',
                        title: 'Tên danh sách video',
                        width: "200px",
                    },
                    // {
                    //     data: 'id',
                    //     title: 'ID',
                    //     width: "50px",
                    //     className: 'mobile-p text-center',
                    // },
                    {
                        data: 'video_id',
                        title: 'ID video',
                        width: "50px",
                        className: 'mobile-p text-center',
                    },
                    {
                        data: 'path',
                        title: 'Video',
                        className: 'text-center',
                        width: "250px",
                        render: function (data, row, table) {
                            return `<video id="video-${table.id}" width="200" height="120" controls><source src="${data}" type="video/mp4"></video>`
                        }
                    },
                    {
                        data: 'name',
                        title: 'Tiêu đề video',
                        width: "250px",
                    },
                    {
                        data: 'created_at',
                        title: 'Thời gian upload',
                        width: "150px",
                    },
                    {
                        data: 'groundTruth',
                        title: 'Nhãn đúng',
                        width: "300px",
                    },
                    {
                        data: 'fullGroundTruthAI',
                        title: 'Nhãn AI',
                        width: "300px",
                    },
                    {
                        data: 'fullGroundTruthAIFrameArray',
                        title: 'Thời gian vi phạm',
                        width: "40%",
                        className: "mobile-p",
                        render: function (data, row, table) {
                            return generateFrameAction(data, table.id, table.fullGroundTruthAIFrameSecond, 'changeFrame', table.fullGroundTruthAI)
                        }
                    },
                    {
                        data: 'fullResult',
                        title: 'Kết quả',
                        width: "100px",
                    },
                ],
                postData: new Form(formSearch),
                pickerOptions: {
                    disabledDate(time) {
                        return time.getTime() > Date.now();
                    },
                    shortcuts: [{
                        text: today,
                        onClick(picker) {
                            const end = moment().startOf('day').format('DD-MM-YYYY');
                            const start = moment().endOf('day').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: toweek,
                        onClick(picker) {
                            const end = moment().endOf('day').format('DD-MM-YYYY');
                            const start = moment().startOf('isoWeek').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: tomonth,
                        onClick(picker) {
                            const end = moment().endOf('day').format('DD-MM-YYYY');
                            const start = moment().startOf('month').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                interval: null,
                groundTruth: null,
                fullGroundTruthAI: null,
                errTxt: 'Lỗi',
                processingTxt: '--Đang xử lý',
                perPage: null,
                offset: null,
                options: [
                    {
                        value: -1,
                        label: 'Tất cả'
                    },
                    {
                        value: 'Đúng',
                        label: 'Đúng'
                    },
                    {
                        value: 'Sai',
                        label: 'Sai'
                    },
                    {
                        value: 'Lỗi',
                        label: 'Lỗi'
                    },
                    {
                        value: 'Đang xử lý',
                        label: 'Đang xử lý'
                    }
                ],
                isLoading: false,
            };
        },
        computed: {
            actions() {
                return [
                    {
                        type: 'click',
                        name: 'changeFrame',
                        action: this.changeFrame
                    },
                ]
            },
        },
        watch: {
            'postData': {
                deep: true,
                handler(val) {
                    this.$refs.table.reload()
                }
            }
        },
        created() {
            this.interval = setInterval(() => {
                this.$refs.table.reload()
            }, 600000)
        },
        methods: {
            reloadTable: debounce(function() {
                this.$refs.table.reload()
            }, 300),
            callBackTable(data) {
                this.perPage = data.length
                this.offset = data.start
            },
            changeFrame(rowId, rowValue) {
                let video = document.getElementById(`video-${rowId}`);
                video.currentTime = rowValue
            },
            handleGroundTruth(arr) {
                let result = ''

                arr.forEach(function (item, key) {
                    result += item

                    if (key < arr.length - 1) {
                        result += ', '
                    }
                })

                return result
            },
            async exportExcel() {
                try {
                    this.isLoading = true
                    this.postData['perPage'] = this.perPage
                    this.postData['offset'] = this.offset

                    let res = await axios.post(API_VIDEO_DETAIL_EXPORT_DEV, this.postData, {
                        responseType: 'blob'
                    })
                    downloadFile(res)
                    this.isLoading = false
                }
                catch (e) {
                    this.isLoading = false
                    console.log('err api: ', e);
                }
            }
        },
        destroyed() {
            clearInterval(this.interval)
        }
    }
</script>