<template>
    <div>
        <el-select
            v-model="innerValue"
            multiple
            filterable
            :filter-method="(str) => filterMethod(str)"
            placeholder="Chọn vi phạm"
            style="width: 100%"
        >
            <template v-if="!isApi">
                <el-option
                    v-for="item in violations"
                    :key="item.id"
                    :label="item.name"
                    :value="isDetail ? item.code : item.id">
                </el-option>
            </template>

            <template v-else>
                <el-option
                    v-for="item in violations"
                    :key="item.id"
                    :label="item.name"
                    :value="item.code">
                </el-option>
            </template>
        </el-select>
    </div>
</template>

<script>
    import { convertViToEn } from '~/helpers/utilsHelper'
    import { GROUND_TRUTH_LIST, GROUND_TRUTH_LIST_API } from '~/constants/groundTruth'

    export default {
        name: 'GroundTruthComponent',
        props: {
            value: {
                type: Array,
                default: []
            },
            isDetail: {
                type: Boolean,
                default: false
            },
            isApi: {
                type: Boolean,
                default: false
            }
        },
        data () {
            return {
                innerValue: null,
                violations: null,
            }
        },
        mounted() {
            this.violations = this.isApi ? GROUND_TRUTH_LIST_API : GROUND_TRUTH_LIST
        },
        created() {
            if (this.value) {
                this.innerValue = this.value
            }
        },
        watch: {
            innerValue(newVal) {
                this.$emit('input', newVal)
            },
            value(newVal) {
                this.innerValue = newVal
            }
        },
        methods: {
            filterMethod(str) {
                const keyword = str.trim()
                if (keyword !== '') {
                    this.violations = this.violations.filter(item => {
                        return (
                            convertViToEn(item.name.toLowerCase())
                                .indexOf(convertViToEn(keyword.toLowerCase())) > -1
                        )
                    })
                } else {
                    this.violations = GROUND_TRUTH_LIST
                }
            },
        }
    }
</script>