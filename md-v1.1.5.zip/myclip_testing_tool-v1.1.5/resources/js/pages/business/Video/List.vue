<template>
    <div>
        <portlet title="Kết quả kiểm duyệt video">
            <template #tool>
                <el-button
                    type="success"
                    icon="el-icon-download"
                    @click="exportExcel()"
                >
                    Xuất báo cáo
                </el-button>
            </template>

            <div class="row mb-4">
                <div class="col-md-12">
                    <ground-truth-component v-model="postData.ground_truth_id" />
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <el-date-picker
                        v-model="postData.datePicked"
                        type="daterange"
                        align="center"
                        :start-placeholder="$t('table.start')"
                        :end-placeholder="$t('table.end')"
                        :picker-options="pickerOptions"
                        fomat="dd-MM-yyyy"
                        value-format="dd-MM-yyyy"
                    > </el-date-picker>
                </div>

                <div class="col-md-3"></div>

                <div class="col-md-3">
                    <el-input
                        v-model="postData.keyword"
                        placeholder="Nhập tên danh sách"
                        clearable
                    >
                        <i slot="prefix" class="el-input__icon el-icon-search"></i>
                    </el-input>
                </div>
            </div>

            <data-table
                ref="table"
                :columns="columns"
                :url="listingUrl"
                :post-data="postData"
                :length-change="false"
                :b-info="false"
                :paging="false"
                :searching="false"
            />
        </portlet>
    </div>
</template>

<script>
    import moment from 'moment'
    import { debounce } from 'lodash'
    import axios from 'axios'
    import { API_VIDEO_LIST, API_VIDEO_EXPORT } from '~/constants/url'
    import { downloadFile } from '~/helpers/downloadFile'
    import Form from 'vform'
    import Portlet from '~/components/common/Portlet'
    import DataTable from '~/components/common/DataTable'
    import GroundTruthComponent from './GroundTruthComponent'

    const formSearch = {
        // datePicked: [moment().subtract(30, "days").format('DD-MM-YYYY'), moment().endOf('day').format('DD-MM-YYYY')],
        datePicked: [moment().startOf('month').format('DD-MM-YYYY'), moment().endOf('day').format('DD-MM-YYYY')],
        ground_truth_id: [],
        keyword: ''
    }

    export default {
        name: 'List',
        components: {
            DataTable,
            Portlet,
            GroundTruthComponent
        },
        data() {
            let today = this.$t('table.today')
            let toweek = this.$t('table.toweek')
            let tomonth = this.$t('table.tomonth')
            return {
                listingUrl: API_VIDEO_LIST,
                columns: [
                    {
                        data: 'ground_truth',
                        title: 'Nội dung vi phạm',
                        sortable: false
                    },
                    {
                        data: 'name',
                        title: 'Tên danh sách video',
                        sortable: false
                    },
                    {
                        data: 'count_video',
                        title: 'Số lượng video đánh giá',
                        sortable: false
                    },
                    {
                        data: 'count_true',
                        title: 'Số lượng video đúng',
                        sortable: false
                    },
                    {
                        data: 'count_wrong',
                        title: 'Số lượng video sai',
                        sortable: false
                    },
                    {
                        data: 'ratio',
                        title: 'Độ chính xác mô hình',
                        sortable: false
                    },
                ],
                postData: new Form(formSearch),
                pickerOptions: {
                    disabledDate(time) {
                        return time.getTime() > Date.now();
                    },
                    shortcuts: [{
                        text: today,
                        onClick(picker) {
                            const end = moment().startOf('day').format('DD-MM-YYYY');
                            const start = moment().endOf('day').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: toweek,
                        onClick(picker) {
                            const end = moment().endOf('day').format('DD-MM-YYYY');
                            const start = moment().startOf('isoWeek').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: tomonth,
                        onClick(picker) {
                            const end = moment().endOf('day').format('DD-MM-YYYY');
                            const start = moment().startOf('month').format('DD-MM-YYYY');
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                interval: null
            };
        },
        watch: {
            'postData': {
                deep: true,
                handler(val) {
                    this.reloadTable();
                }
            }
        },
        created() {
            this.interval = setInterval(() => {
                this.$refs.table.reload()
            }, 600000)
        },
        methods: {
            reloadTable: debounce(function() {
                this.$refs.table.reload()
            }, 300),
            async exportExcel() {
                try {
                    let res = await axios.post(API_VIDEO_EXPORT, this.postData, {
                        responseType: 'blob'
                    })
                    downloadFile(res)
                }
                catch (e) {
                    console.log('err api: ', e);
                }
            },
        },
        destroyed() {
            clearInterval(this.interval)
        }
    }
</script>

<style scoped>
</style>
