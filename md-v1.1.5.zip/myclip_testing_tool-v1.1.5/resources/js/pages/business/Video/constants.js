export const IS_ERROR = -1
export const IS_NOT_GROUND_TRUTH = 0
export const IS_GROUND_TRUTH = 1
