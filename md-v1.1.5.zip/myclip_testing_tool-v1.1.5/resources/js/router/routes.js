const NotFound = () => import('~/pages/errors/404.vue').then(m => m.default || m)

const Login = () => import('~/pages/auth/Login.vue').then(m => m.default || m)
const Profile = () => import('~/pages/Profile.vue').then(m => m.default || m)

/*
 |--------------------------------------------------------------------------
 | Business
 |--------------------------------------------------------------------------
 */
const Censorship = () => import('~/pages/business/Video/Censorship.vue').then(m => m.default || m)
const List = () => import('~/pages/business/Video/List.vue').then(m => m.default || m)
const Detail = () => import('~/pages/business/Video/Detail.vue').then(m => m.default || m)
const DetailApi = () => import('~/pages/business/Video/DetailApi.vue').then(m => m.default || m)
const DetailDev = () => import('~/pages/business/Video/DetailDev.vue').then(m => m.default || m)

import store from '~/store'

export default {
    default: {
        path: '/', redirect:'/login'
    },
    profile: {path: '/profile', name: 'profile', component: Profile, meta: {title: 'Thông tin người dùng'}},
    login: {path: '/login', name: 'login', component: Login},
    censorship: {path: '/censorship', name: 'censorship', component: Censorship, meta: { title: 'Kiểm duyệt video' }},
    list: {path: '/videos', name: 'videos', component: List, meta: { title: 'Kết quả kiểm duyệt' }},
    detail: {path: '/videos/detail', name: 'detail', component: Detail, meta: { title: 'Kêt quả kiểm duyệt chi tiết' }},
    detailApi: {path: '/videos/detailApi', name: 'detailApi', component: DetailApi, meta: { title: 'Kêt quả kiểm duyệt chi tiết (Api)' }},
    detail__dev: {path: '/videos/detail__dev', name: 'detail__dev', component: DetailDev, meta: { title: 'Kêt quả kiểm duyệt chi tiết (Dev)' }},
    not_found: {
        path: '*',
        component: NotFound,
        beforeEnter(to, from, next) {
            let defaultUrl = store.getters['auth/check'] ? store.getters['auth/user'].defaultUrl : 'login'
            next({name: defaultUrl})
        }
      }
}

