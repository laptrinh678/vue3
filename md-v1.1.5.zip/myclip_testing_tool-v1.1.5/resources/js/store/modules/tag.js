// state
export const state = {
    tagsArr: [],
    currentTagNode: null,
    currentScript: null,
    tagChosen: null,
    selectionInfo: null,
    tagsArrSelected: [],
    closePopover: false
}

// mutations
export const mutations = {

    setTagArr(state, tagsArr) {
        state.tagsArr = tagsArr
    },
    setTagSelected(state, tagsArrSelected) {
        state.tagsArrSelected = tagsArrSelected
    },

    setCurrentTagNode(state, currentTagNode) {
        state.currentTagNode = currentTagNode
    },

    setCurrentScript(state, currentScript) {
        state.currentScript = currentScript
    },

    setTagChosen(state, tagChosen) {
        state.tagChosen = tagChosen
    },
    setClosePopover(state,closePopover){
        state.closePopover = closePopover
    },
    setSelectionInfo(state, selectionInfo) {
        state.selectionInfo = selectionInfo
    }
}
