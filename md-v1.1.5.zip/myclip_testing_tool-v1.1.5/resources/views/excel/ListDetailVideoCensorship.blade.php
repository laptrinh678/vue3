<tr>
    <td colspan="6" style="text-align: center"><strong>Bảng thống kê kết quả chi tiết kiểm duyệt video</strong></td>
</tr>
<tr>
    <td colspan="6" style="text-align: center"><strong>{{$time}}</strong></td>
</tr>
<table>
    <thead>
        <tr>
            <th style="vertical-align: middle; text-align:center; width: 5px"><strong>STT</strong></th>
            <th style="vertical-align: middle; text-align:center; width: 25px"><strong>Tên danh sách video</strong></th>
            <th style="vertical-align: middle; text-align:center; width: 10px"><strong>ID video</strong></th>
            <th style="vertical-align: middle; text-align:center; width:80px"><strong>Tiêu đề video</strong></th>
            <th style="vertical-align: middle; text-align:center; width:50px"><strong>Nhãn đúng</strong></th>
            <th style="vertical-align: middle; text-align:center; width:50px"><strong>Nhãn AI</strong></th>
            <th style="vertical-align: middle; text-align:center; width: 25px"><strong>Thời gian vi phạm</strong></th>
            <th style="vertical-align: middle; text-align:center; width: 25px"><strong>Kết quả</strong></th>
        </tr>
    </thead>

    <tbody>
    @foreach($data as $index => $value)
        <tr>
            <td style="text-align: center">{{ $index + 1 }}</td>
            <td style="text-align: center">{{ $value['playlist_name'] }}</td>
            <td style="text-align: center">{{ $value['id'] }}</td>
            <td style="t">{{ $value['name'] }}</td>
            <td style="">{{ $value['groundTruth'] }}</td>
            <td style="">{{ $value['groundTruthAI'] }}</td>
            <td style="">{{ $value['groundTruthAIFrame'] }}</td>
            <td style="text-align: center">{{ $value['result'] }}</td>
        </tr>
    @endforeach
    </tbody>

</table>
