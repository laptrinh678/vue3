<tr>
    <td colspan="6" style="text-align: center"><strong>Bảng thống kê kết quả kiểm duyệt video</strong></td>
</tr>
<tr>
    <td colspan="6" style="text-align: center"><strong>{{$time}}</strong></td>
</tr>
<table>
    <thead>
        <tr>
            <th style="vertical-align: middle; text-align:center; width:30px"><strong>Nội dung vi phạm</strong></th>
            <th style="vertical-align: middle; text-align:center; width:25px"><strong>Tên danh sách video</strong></th>
            <th style="vertical-align: middle; text-align:center; width:25px"><strong>Số lượng video đánh giá</strong></th>
            <th style="vertical-align: middle; text-align:center; width:25px"><strong>Số lượng video đúng</strong></th>
            <th style="vertical-align: middle; text-align:center; width:25px"><strong>Số lượng video sai</strong></th>
            <th style="vertical-align: middle; text-align:center; width:25px"><strong>Độ chính xác mô hình</strong></th>
        </tr>
    </thead>

    <tbody>
    @foreach($data as $index => $value)
        @if ($value['name'] === 'Tổng')
            <tr>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['ground_truth'] }}</td>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['name'] }}</td>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['count_video'] }}</td>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['count_true'] }}</td>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['count_wrong'] }}</td>
                <td style="text-align: center; background-color: #B8CCE4;">{{ $value['ratio'] }}</td>
            </tr>
        @else
            <tr>
                <td style="text-align: center">{{ $value['ground_truth'] }}</td>
                <td style="text-align: center">{{ $value['name'] }}</td>
                <td style="text-align: center">{{ $value['count_video'] }}</td>
                <td style="text-align: center">{{ $value['count_true'] }}</td>
                <td style="text-align: center">{{ $value['count_wrong'] }}</td>
                <td style="text-align: center">{{ $value['ratio'] }}</td>
            </tr>
        @endif
    @endforeach
    </tbody>

</table>
