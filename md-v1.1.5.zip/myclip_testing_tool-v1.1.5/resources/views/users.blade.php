<table>
    <thead>
    <tr>
        <th>Tên Tagger</th>
        <th>Loại ảnh</th>
        <th>Tổng ảnh</th>
        <th>Đã gán</th>
        <th>Đã Review</th>
        <th>Đạt</th>
        <th>Không đạt</th>
    </tr>
    </thead>
    @foreach($users as $value)
        <tbody>
        @foreach ($value as $key=>$item)
            @if(!empty($item['name']))
            <tr>
                @if($key === 0)
                    <td rowspan="{{count($value)-1}}" class="col-user">{{$value['name']}}</td>
                @endif
                <td>{{$item['name']}}</td>
                <td>{{$item['images_count_count']}}</td>
                <td>{{$item['all_tagged_count']}}</td>
                <td>{{$item['images_reviewed_count']}}</td>
                <td>{{$item['images_success_count']}}</td>
                <td>{{$item['images_reject_count']}}</td>
            </tr>
            @endif
        @endforeach
        </tbody>
    @endforeach
</table>

