<?php
/**
 * Created by PhpStorm.
 * User: hungnm
 * Date: 5/2/2019
 * Time: 8:34 AM
 */

Route::group(['namespace' => 'Admin','prefix' => '/profile', 'as' => 'profile.'], function () {

    Route::post('update-profile','UserController@updateProfile')->name('update-profile');
    Route::post('change-password','UserController@ChangePassword')->name('change-password');

});