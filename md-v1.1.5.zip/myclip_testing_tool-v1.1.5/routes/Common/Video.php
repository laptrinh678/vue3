<?php
Route::group(['namespace' => 'Common', 'prefix' => '/videos', 'as' => 'video.'], function () {
    Route::post('', 'VideoController@index');
    Route::post('detail', 'VideoController@detail');
    Route::post('detail__dev', 'VideoController@detailDev');
    Route::post('detailApi', 'VideoController@detailApi');
    Route::get('playlists', 'VideoController@getPlaylists');
    Route::post('store', 'VideoController@store');
    Route::post('export', 'VideoController@export');
    Route::post('detail/export', 'VideoController@exportDetail');
    Route::post('detail/export__dev', 'VideoController@exportDetailDev');
});
