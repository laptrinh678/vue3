const path = require('path')
const mix = require('laravel-mix')

mix.config.vue.esModule = true

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 */

mix.js('resources/js/app.js', 'public/js')
    .sass('resources/sass/app.scss', 'public/css')
    .sass('resources/sass/vendors/vendors.scss', 'public/css')
    .copyDirectory('resources/assets/img', 'public/images')
    .sourceMaps(false, 'source-map')
    .disableNotifications();

mix.webpackConfig({
    plugins: [
        // new BundleAnalyzerPlugin()
    ],
    resolve: {
        extensions: ['.js', '.json', '.vue'],
        alias: {
            '~': path.join(__dirname, './resources/js'),
            '~assets': path.join(__dirname, './resources/assets')
        }
    },
    output: {
        chunkFilename: 'js/[name].[chunkhash].js',
        publicPath: mix.config.hmr ? '//localhost:8080' : '/'
    }
})
